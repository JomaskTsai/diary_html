/****************************
*project: bluetooth low energy local network
*function: custom application
*
*
*author: book chen
*file: custom.c
*****************************
*/
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"

/* CUSTOM HERDER FILES */
#include "includes.h"

enum Custom_States{
  CustomIdleState=0,
  CustomInitialState,
  CustomRunState,
};

#if 0

CUSTOM_CONTROL CustomCtrl;

//CustomInit is called in SimpleBLEPeripheral_Init
void CustomInit(void){
  Uart0Init(); //uart0 is for serial data communication protocal
  Uart0Open(); 
  Uart1Init(); //uart1 is for shell
  Uart1Open();
  I2cInit(); //I2c is for PMIC use. PMIC!? yes,PMIC!
  Timer1Init();
  SdcpInit(); //sdcp is brief of Serial Data Communication Protocal
  ShellInit();
  CustomCtrl.State=CustomIdleState;
}

void CustomStart(void){ CustomCtrl.State=CustomInitialState; }

//CustomSvc is called in osal_start_system
void CustomSvc(void){
  switch(CustomCtrl.State){
    case CustomIdleState: break;
    case CustomInitialState: 
      SdcpStart();
      ShellStart(); 
      CustomCtrl.State=CustomRunState; 
      break;
    case CustomRunState: //put service here.
      Uart0Svc();
      Uart1Svc();
      SdcpSvc();
      ShellSvc();
      //if(Timer1Ctrl.TimerU8==0){
      //  Timer1Ctrl.TimerU8=200;
        //Uart1CharTx('t');
      //}
      break;
    default: break;	
  }
}

#endif


