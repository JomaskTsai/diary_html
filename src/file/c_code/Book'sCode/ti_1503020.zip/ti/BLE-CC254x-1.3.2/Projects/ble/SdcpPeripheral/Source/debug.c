
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"

/*#include "type.h"
#include "define.h"
#include "uart0.h"
#include "uart1.h"
#include "debug.h"
*/

#include "includes.h" // custom header files

#define LINE_BYTE_NUMB  (16)

void DebugBufferDump(u8_t *pData,u32_t Length){
  u8_t LineByteCounter,LineCounter;
  u32_t i;  

  LineByteCounter=0;
  LineCounter=0;

  for(i=0;i<Length;i++) {
    if(LineByteCounter==LINE_BYTE_NUMB) {
      LineByteCounter=0;
      LineCounter++;
    }
    
    if(LineByteCounter==0){
      //switch line symble
      DebugStringPrint((char *)"\n\r");
      DebugU8Print(LineCounter);   
      DebugStringPrint("h");              
    }
    LineByteCounter++;              
    DebugStringPrint(" ");
    DebugU8Print(*pData);
    pData++;

  }
}

/*****************
* DebugU8Print:
* show unsigned char value 
*******************/
void DebugU8Print(u8_t Data)
{
  u8_t i;

  // 0xAB
  // A => 'A'
  // B => 'B'

  i=Data&0xf0;
  i=i>>4;
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  i=Data&0x0f;
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
}

/*****************
* DebugInt16uPrint:
* show unsigned int value (16 bit)
*******************/
void DebugU16Print(u16_t Data)
{
  u8_t i;

  i=(u8_t)((Data&0xf000)>>12);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x0f00)>>8);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x00f0)>>4);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);

  i=(u8_t)(Data&0x000f);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
}
/*****************
* Debugu32_tPrint:
* show unsigned long value (32 bit)
*******************/
void DebugU32Print(u32_t Data)
{
  u8_t i;

  i=(u8_t)((Data&0xf0000000)>>28);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x0f000000)>>24);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x00f00000)>>20);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);

  i=(u8_t)((Data&0x000f0000)>>16);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);

  i=(u8_t)((Data&0x0000f000)>>12);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x00000f00)>>8);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
  
  i=(u8_t)((Data&0x000000f0)>>4);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);

  i=(u8_t)(Data&0x0000000f);
  i=DebugHex2AsciiCharGet(i);
  Uart0CharTx(i);
}
/*****************
* DebugStringPrint:
* show string 
*******************/
void DebugStringPrint(char *pString)
{
  //Uart0StringTx(pString);
  while(*pString!=0) Uart0CharTx(*pString++);
}

void DebugHex16bitPrint(u16_t ulNum)
{
  u8_t i;
  
  i=(u8_t)((ulNum&0xFF00)>>8);
  Uart0CharTx(i);
  
  i=(u8_t)((ulNum&0x00FF));
  Uart0CharTx(i);
}


//LCD Print
u8_t DebugHex2AsciiCharGet(u8_t ucdata)
{
  if (ucdata <=9)  return ucdata+48;
  if (ucdata>=0xA && ucdata <=0xF) return ucdata + 65 - 10;
  return 0;
}

