/****************************
*project: BLE local network
*function: i2c driver for cc2541
*this code reference to component\hal\target\cc2541ST\hal_i2c.c
*
*author: book chen
*file: i2c.c
*****************************
*/
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"

#include "includes.h" // custom header files

#define I2C_ENS1            0x40   
#define I2C_STA             0x20 
#define I2C_STO             0x10 
#define I2C_SI              0x08 
#define I2C_AA              0x04 
#define I2C_MST_RD_BIT      0x01  // Master RD/WRn bit to be OR'ed with Slave address.

#define I2C_CLOCK_MASK      0x83

#define I2C_PXIFG           P2IFG
#define I2C_IF              P2IF
#define I2C_IE              BV(1)

  // HAL_I2C_MASTER mode statuses.
enum cc2541_i2c_states{
  I2cMasterStarted   = 0x08,
  I2cMasterRepStart  = 0x10,
  I2cMasterAddrAckW  = 0x18,
  I2cMasterAddrNackW = 0x20,
  I2cMasterDataAckW  = 0x28,
  I2cMasterDataNackW = 0x30,
  I2cMasterLostArb   = 0x38,
  I2cMasterAddrAckR  = 0x40,
  I2cMasterAddrNackR = 0x48,
  I2cMasterDataAckR  = 0x50,
  I2cMasterDataNackR = 0x58,
};

//Table 20-6. Clock Rates Defined at 32 MHz
//clock[CR2,CR1,CR0]={I2CCFG[7],I2CCFG[1],I2CCFG[0]}
enum cc2541_i2c_clock{
  I2cMasterClock_123KHZ = 0x00,
  I2cMasterClock_144KHZ = 0x01,
  I2cMasterClock_165KHZ = 0x02,
  I2cMasterClock_197KHZ = 0x03,
  I2cMasterClock_33KHZ  = 0x80,
  I2cMasterClock_267KHZ = 0x81,
  I2cMasterClock_533KHZ = 0x82
};

I2C_CONTROL I2cCtrl;

void I2cMasterStartCondition(void) {
  I2CCFG &= ~I2C_SI;
  I2CCFG |= I2C_STA;
  while ((I2CCFG & I2C_SI) == 0);
  I2CCFG &= ~I2C_STA;
}

void I2cMasterStopCondition(void){
  I2CCFG |= I2C_STO;                
  I2CCFG &= ~I2C_SI;                
  while ((I2CCFG & I2C_STO) != 0);  
}

uint8 I2cMasterRead(void){
  I2CCFG &= ~I2C_SI;                
  while ((I2CCFG & I2C_SI) == 0);   
  return I2CDATA;                  
}

void I2cMasterWrite(uint8 WriteData){
  I2CDATA = WriteData;                  
  I2CCFG &= ~I2C_SI;                
  while ((I2CCFG & I2C_SI) == 0);   
}

//DeviceAddress is 8 bit,not 7 bit. this means DeviceAddress=dev_addr<<1;
//ReadWriteFlag is 0 for write,1 for read
//return i2c state machine
uint8 I2cMasterStart(uint8 DeviceAddress,uint8 ReadWriteFlag){
  if(ReadWriteFlag>1) return 0; //invalid read write flag
  DeviceAddress=DeviceAddress+ReadWriteFlag;
  I2cMasterStartCondition();
  if (I2CSTAT == I2cMasterStarted) I2cMasterWrite(DeviceAddress); // A start condition has been transmitted 
  return I2CSTAT;
}

//I2cOpen is better?
void I2cInit(void){
  I2CWC = 0x00; //enable i2c function,disable pullup of sda & scl,enable sda & scl
  I2CCFG &= ~0x83; //[CR2,CR1,CR0]=I2CCFG.7,I2CCFG.1,I2CCFG.0
  I2CCFG |= I2cMasterClock_123KHZ;
  I2CCFG |= 0x40; //I2C enable bit is I2CCFG.6
  
  I2cCtrl.State=0;
  I2cCtrl.Error=0;
}

//void I2cClose(void){
void I2cDisable(void){
  I2CCFG &= ~0x40;
}

void I2cRead(uint8 DeviceAddress,uint8 *pData,uint8 Length){
  I2cCtrl.Error=1; //assume it has error
  if(Length==0) return;
  if(I2cMasterStart(DeviceAddress,1)!=I2cMasterAddrAckR) return; //device does not exist.
  if(Length>1) I2CCFG |= I2C_AA; //reply ack if needed.
  while(Length!=0){
    if(Length==1) I2CCFG &= ~I2C_AA;
    *pData=I2cMasterRead();
    pData++;
    Length--;
    if(Length!=0){
      if(I2CSTAT!=I2cMasterDataAckR) break; //something goes wrong
    }	
    else{
      if(I2CSTAT!=I2cMasterDataNackR) break; //something goes wrong
      I2cCtrl.Error=0; //read success
      break;
    }
  }
  I2cMasterStopCondition();
  //if(I2cCtrl.Error) printf("\nthere is error!")
}

void I2cWrite(uint8 DeviceAddress,uint8 *pData,uint8 Length){
  I2cCtrl.Error=1; //assume it has error
  if(Length==0) return;
  if(I2cMasterStart(DeviceAddress,0)!=I2cMasterAddrAckW) return; //device does not exist.
  while(Length!=0){
    I2cMasterWrite(*pData);
    if(I2CSTAT!=I2cMasterDataAckW) break;
    pData++;
    Length--;
    if(Length==0){
      I2cCtrl.Error=0;	
      break;	
    }
  }
  I2cMasterStopCondition();
}

