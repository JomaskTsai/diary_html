#ifndef CUSTOM_H
#define CUSTOM_H

typedef struct{
  u8_t State;

}CUSTOM_CONTROL;

extern CUSTOM_CONTROL CustomCtrl;

extern void CustomInit(void);
extern void CustomSvc(void);
extern void CustomStart(void);

#endif




