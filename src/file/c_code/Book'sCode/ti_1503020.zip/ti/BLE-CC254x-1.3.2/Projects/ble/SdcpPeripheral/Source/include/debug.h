#ifndef DEBUG_H
#define	DEBUG_H

void DebugBufferDump(u8_t *pData,u32_t Length);
void DebugU8Print(u8_t Data);
void DebugU16Print(u16_t Data);
void DebugU32Print(u32_t Data);

void DebugStringPrint(char *pString);
u8_t DebugHex2AsciiCharGet(u8_t ucdata);



#endif	/* DEBUG_H */

