#ifndef DEFINE_H
#define DEFINE_H

//defined in  nano1xxx.h
#define BOOL  u8_t
//#define bool  INT8U
#define TRUE  1 // logic true
#define FALSE 0 // logic false

#define HIGH  1 // bit value high
#define LOW   0 // bit value low

#define ERROR INT8U
#define NO_ERROR 0
#define IS_ERROR 1

#define BUFFER_STATUS_OVERSUN   0x01

#define BUFFER_EMPTY     0
#define BUFFER_NOT_EMPTY 1
#define BUFFER_FULL      2

#define NULL 0

#define RESOURCE_NOT_IN_USE 0
#define RESOURCE_IN_USE     1

#define MY_BIGENDIAN  0
#define MY_LITTLEENDIAN  1

#define SHELL_ENABLE 1

#endif
