#ifndef I2C_H
#define I2C_H

typedef struct{
  u8_t State;
  u8_t Error;
}I2C_CONTROL;

extern I2C_CONTROL I2cCtrl;

void I2cInit(void);
void I2cDisable(void);
//void I2cSvc(void); //use state machine for cpu efficiency 
void I2cWrite(u8_t DeviceAddress,u8_t *pData,u8_t Length);
void I2cRead(u8_t DeviceAddress,u8_t *pData,u8_t Length);

#endif

