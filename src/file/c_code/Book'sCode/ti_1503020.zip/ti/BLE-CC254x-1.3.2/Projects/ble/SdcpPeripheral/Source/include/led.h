#ifndef LED_H
#define LED_H

extern void LedInit(void);
extern void LedStart(void);
extern void LedSvc(void);

#endif


