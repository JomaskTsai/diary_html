#ifndef SDCP_H
#define SDCP_H

//sum of whole packet must be 0
#define SDCP_HEADER_SYNCBYTE       0x5a  //combine 0x55 0xaa to 0x51
#define SDCP_HEADER_SYNC           0
#define SDCP_HEADER_CHECKSUM       1  //checksum for packet protection
#define SDCP_HEADER_PAYLOADLENGTH  2  //length of payload data 
#define SDCP_PAYLOAD0              3

#define SDCP_COMMAND_ACK 0x01
#define SDCP_COMMAND_NACK 0x02
#define SDCP_COMMAND_DATA 0x03

#define SDCP_BASIC_LENGTH 3 

//#define SDCP_ACK 0
//#define SDCP_NACK 1

typedef struct{
  u8_t State;
  u8_t RxState;
  u8_t Timer;
  u8_t HasRxPacket;
  u8_t PacketIndex;
  u8_t PacketLength;
}SDCP_CONTROL;

extern SDCP_CONTROL SdcpCtrl;

extern void SdcpInit(void);
extern void SdcpSvc(void);
extern void SdcpStart(void);
extern void SdcpPacketRx(u8_t Data);
extern void SdcpPacketTx(u8_t *pPacketData,u8_t Length);
extern u8_t SdcpChecksumCalculate(u8_t *pDataBuf);

#endif

