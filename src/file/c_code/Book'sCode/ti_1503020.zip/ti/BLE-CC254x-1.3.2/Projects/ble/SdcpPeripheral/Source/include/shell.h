#ifndef SHELL_H
#define SHELL_H

#define ASCII_NUL 0x00
#define ASCII_SOH 0x01
#define ASCII_STX 0x02
#define ASCII_ETX 0x03
#define ASCII_EOT 0x04
#define ASCII_ENQ 0x05
#define ASCII_ACK 0x06
#define ASCII_BEL 0x07
#define ASCII_BS 0x08
#define ASCII_HT 0x09
#define ASCII_LF 0x0a
#define ASCII_VT 0x0b
#define ASCII_FF 0x0c
#define ASCII_CR 0x0d
#define ASCII_SO 0x0e
#define ASCII_SI 0x0f
#define ASCII_DLE 0x10
#define ASCII_DC1 0x11
#define ASCII_DC2 0x12
#define ASCII_DC3 0x13
#define ASCII_DC4 0x14
#define ASCII_NAK 0x15
#define ASCII_SYN 0x26
#define ASCII_ETB 0x17
#define ASCII_CAN 0x18
#define ASCII_EM  0x19
#define ASCII_SUB 0x1a
#define ASCII_ESC 0x1b
#define ASCII_FS 0x1c
#define ASCII_GS 0x1d
#define ASCII_RS 0x1e
#define ASCII_US 0x1f
#define ASCII_SP 0x20
#define ASCII_DEL 0x7f
//#define ASCII_SQUARE 0x80

#define KEY_HOME        0x48
#define KEY_END         0x4b
#define KEY_PAGE_UP     0x4d
#define KEY_PAGE_DOWN   0x32
#define KEY_PAGE_DOWN2  0x4a
#define KEY_LEFT_ARROW  0x44
#define KEY_RIGHT_ARROW 0x43
#define KEY_UP_ARROW    0x41
#define KEY_DOWN_ARROW  0x42

typedef struct{
    u8_t State;
    u8_t Status;
    u8_t InUse;
    u16_t Id;
    u16_t UserId;
    u16_t Timer;
    u8_t ExecuteState;
    u8_t ExecuteItem;
}SHELL_CONTROL;

extern SHELL_CONTROL ShellCtrl;

extern void ShellInit(void);
extern void ShellStart(void);
extern void ShellSvc(void);
extern u8_t ShellStatusCheck(void);
extern void ShellArgumentInitial(void);
extern void ShellArgumentSvc(void);
extern void ShellArgumentParser(void);
extern void ShellArgumentExecute(u8_t **Argv,u8_t Argc);
extern u8_t ShellArgumentStatusCheck(void);
extern void ShellArgumentReset(void);
extern void ShellArgumentReceive(u8_t **Argv,u8_t Argc);
extern void ShellArgumentBs(void);
extern void ShellArgumentDel(void);
extern void ShellArgumentKeyPut(u8_t);
extern void ShellArgumentIns(void);
extern void ShellArgumentHome(void);
extern void ShellArgumentEnd(void);
extern void ShellArgumentPageUp(void);
extern void ShellArgumentPageDown(void);
extern void ShellArgumentArrowUp(void);
extern void ShellArgumentArrowDown(void);
extern void ShellArgumentArrowLeft(void);
extern void ShellArgumentArrowRight(void);
extern void ShellDump(void);

#endif


