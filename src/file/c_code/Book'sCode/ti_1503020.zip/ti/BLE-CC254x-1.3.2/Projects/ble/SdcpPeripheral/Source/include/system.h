#ifndef SYSTEM_H
#define SYSTEM_H

/*typedef enum {
SystemIdleState=0,
SystemInitial0State,
SystemMonitorState
}SYSTEM_STATES;
*/

typedef struct{
  u8_t State;
  u8_t Endian;
  u16_t Timer;
}SYSTEM_CONTROL;

//extern SYSTEM_CONTROL SystemCtrl;

extern void SystemInit(void);
extern void SystemStart(void);
extern void SystemSvc(void);
extern void SystemMemoryCopy(u8_t *pSource,u8_t *pDestinaiton,u8_t Length);
extern u8_t SystemStringCompare(u8_t *pString1,u8_t *pString2);

#endif



