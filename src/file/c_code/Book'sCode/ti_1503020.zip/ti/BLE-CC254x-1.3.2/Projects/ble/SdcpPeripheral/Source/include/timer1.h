#ifndef TIMER1_H
#define TIMER1_H

typedef struct{
  u8_t State;
  u8_t TimerU8;
  u8_t HasTimerInterrupt;

}TIMER1_CONTROL;

extern TIMER1_CONTROL Timer1Ctrl;

extern void Timer1Init(void);

#endif

