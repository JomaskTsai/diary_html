#ifndef TIMER3_H
#define TIMER3_H

typedef struct{
  u8_t State;
  u8_t TimerU16;
}TIMER3_CONTROL;

extern TIMER3_CONTROL Timer3Ctrl;

extern void Timer3Init(void);

#endif

