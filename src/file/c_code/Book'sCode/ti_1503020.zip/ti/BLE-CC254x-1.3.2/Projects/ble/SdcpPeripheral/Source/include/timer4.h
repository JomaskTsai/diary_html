#ifndef TIMER4_H
#define TIMER4_H

typedef struct{
  u8_t State;
  u16_t TimerU16;
}TIMER4_CONTROL;

extern TIMER4_CONTROL Timer4Ctrl;

extern void Timer4Init(void);

#endif

