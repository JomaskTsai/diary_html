#ifndef TYPE_H
#define TYPE_H
								   
typedef char s8_t;
typedef unsigned char u8_t;
typedef short s16_t;  //in keil 51, int is 16 bits
typedef unsigned short u16_t; //in keil 51,int is 16 bits 
typedef long s32_t;
typedef unsigned long u32_t;

typedef union {
    u32_t ui;
    u16_t us[2];
    u8_t uc[4];
}unui_t; //UN_UI;

typedef union {
    u16_t us;
    u8_t uc[2];
}unus_t; //UN_US;

#endif

