#ifndef UART0_H
#define UART0_H

#define UART0_MAX_BUFFER_SIZE	100
//#define BUFFER_EMPTY		0
//#define BUFFER_NOT_EMPTY	1
//#define BUFFER_FULL		2

typedef struct{
  u8_t Status; // bit0:overflow
  u8_t Put;
  u8_t Get;
  u8_t Data[UART0_MAX_BUFFER_SIZE];
}UART0_BUFFER_CONTROL;

//9600 19200 38400 57600 115200...5 baudrates are tested
#define UART0_BAUDRATE 57600 

typedef struct{
  u8_t State;
  u8_t Timer;
  //u8_t HasRxData;
  //u8_t RxData;
  //u8_t WriteLength;
  //u8_t WriteData;
  //u8_t HasMoreData;
  //u8_t IsTransmiting;

  u8_t UartTxTransmit;
  UART0_BUFFER_CONTROL TxBuffer;
  UART0_BUFFER_CONTROL RcBuffer;
}UART0_CONTROL;

extern UART0_CONTROL Uart0Ctrl;

extern void Uart0Init(void);
extern void Uart0Open(void);
extern void Uart0Write(u8_t *pData,u8_t Length);
extern void Uart0Svc(void);
extern void Uart0BufferReset(void);
extern u8_t Uart0TxBufferCheck(void);
extern u8_t Uart0TxBufferCheckIsr(void);
extern void Uart0TxBufferPut(u8_t ucData);
extern u8_t Uart0TxBufferGet(void);
extern u8_t Uart0RxBufferCheck(void);
extern u8_t Uart0RxBufferCheckIsr(void);
extern void Uart0RxBufferPut(u8_t Data);
extern u8_t Uart0RxBufferGet(void);
extern void Uart0CharTx(char ucData);
extern void Uart0StringTx(char *pString);

#endif



