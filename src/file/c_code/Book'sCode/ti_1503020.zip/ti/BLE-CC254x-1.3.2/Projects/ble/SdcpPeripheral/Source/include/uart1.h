#ifndef UART1_H
#define UART1_H

#define UART1_MAX_BUFFER_SIZE	100
//#define BUFFER_EMPTY		0
//#define BUFFER_NOT_EMPTY	1
//#define BUFFER_FULL		2

typedef struct{
  u8_t Status; // bit0:overflow
  u8_t Put;
  u8_t Get;
  u8_t Data[UART1_MAX_BUFFER_SIZE];
}UART1_BUFFER_CONTROL;

//9600 19200 38400 57600 115200...5 baudrates are tested
#define UART1_BAUDRATE 57600 

typedef struct{
  u8_t State;
  u8_t Timer;
  //u8_t HasRxData;
  //u8_t RxData;
  //u8_t WriteLength;
  //u8_t WriteData;
  //u8_t HasMoreData;
  //u8_t IsTransmiting;

  u8_t UartTxTransmit;
  UART1_BUFFER_CONTROL TxBuffer;
  UART1_BUFFER_CONTROL RcBuffer;
}UART1_CONTROL;

extern UART1_CONTROL Uart1Ctrl;

extern void Uart1Init(void);
extern void Uart1Open(void);
extern void Uart1Write(u8_t *pData,u8_t Length);
extern void Uart1Svc(void);
extern void Uart1BufferReset(void);
extern u8_t Uart1TxBufferCheck(void);
extern u8_t Uart1TxBufferCheckIsr(void);
extern void Uart1TxBufferPut(u8_t ucData);
extern u8_t Uart1TxBufferGet(void);
extern u8_t Uart1RxBufferCheck(void);
extern u8_t Uart1RxBufferCheckIsr(void);
extern void Uart1RxBufferPut(u8_t Data);
extern u8_t Uart1RxBufferGet(void);
extern void Uart1CharTx(char ucData);
extern void Uart1StringTx(char *pString);

#endif

