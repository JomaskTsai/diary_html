#ifndef INCLUDES_H
#define INCLUDES_H


#include "include\type.h"
#include "include\define.h"
#include "include\led.h"
#include "include\uart1.h"
#include "include\uart0.h"
#include "include\i2c.h"
#include "include\timer1.h"
#include "include\timer3.h"
#include "include\timer4.h"
#include "include\system.h"
#include "include\shell.h"
#include "include\sdcp.h"
#include "include\debug.h"

#include "include\custom_task.h"

#endif

