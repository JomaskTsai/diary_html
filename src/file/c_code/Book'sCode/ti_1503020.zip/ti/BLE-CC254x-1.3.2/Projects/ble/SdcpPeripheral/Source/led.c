/****************************
*project: bluetooth low energy local network
*function: BLE peripheral using SPP profile
*driver for cc2541 uart 0
*uart0 is for shell & debug use
*
*author: book chen
*file: uart0.c
*****************************
*/
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"
//#include "hal_drivers.h"
#include "hal_led.h"

#include "includes.h"  // custom header files

enum {
LedIdleState=0,
LedTimer1aState,
LedTimer1bState,
LedTimer3aState,
LedTimer3bState,
LedTimer4aState,
LedTimer4bState,
}LedStates;

u8_t LedState;

void LedInit(void){
  //P1DIR |= 0x01; // Set LED GPIOs to outputs.
  //P1_0=1;
  HalLedOnOff(HAL_LED_1,HAL_LED_MODE_ON);
  LedState=LedIdleState;
}

void LedStart(void){ 
  //LedState=LedTimer1aState; 
  //LedState=LedTimer3aState; 
  LedState=LedTimer4aState; 
}

void LedSvc(void){
  switch(LedState){
    case LedIdleState: break;
  case LedTimer1aState: 
      if(Timer1Ctrl.TimerU8!=0) break;
      Timer1Ctrl.TimerU8=100;
      //P1_0=1;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_ON);
      LedState=LedTimer1bState;
      break;	
  case LedTimer1bState: 
      if(Timer1Ctrl.TimerU8!=0) break;
      Timer1Ctrl.TimerU8=100;
      //P1_0=0;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_OFF);
      LedState=LedTimer1aState;
      break;	
    case LedTimer3aState: 
      if(Timer3Ctrl.TimerU16!=0) break;
      Timer3Ctrl.TimerU16=100;
      //P1_0=1;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_ON);
      LedState=LedTimer3bState;
      break;	
    case LedTimer3bState: 
      if(Timer3Ctrl.TimerU16!=0) break;
      Timer3Ctrl.TimerU16=100;
      //P1_0=0;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_OFF);
      LedState=LedTimer3aState;
      break;	
    case LedTimer4aState: 
      if(Timer4Ctrl.TimerU16!=0) break;
      Timer4Ctrl.TimerU16=100;
      //P1_0=1;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_ON);
      LedState=LedTimer4bState;
      break;		
    case LedTimer4bState: 
      if(Timer4Ctrl.TimerU16!=0) break;
      Timer4Ctrl.TimerU16=100;
      //P1_0=0;
      HalLedOnOff(HAL_LED_1,HAL_LED_MODE_OFF);
      LedState=LedTimer4aState;
      break;		
    default: break;
  }
}



