/****************************
*project: BLE network
*function: Serial Data Communication Protocal
*
*author: book chen
*file: uart0.c
*****************************
*/
#include "bcomdef.h"
#include "OSAL.h"
#include "OSAL_PwrMgr.h"

#include "OnBoard.h"
#include "hal_adc.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_lcd.h"
#include "hal_uart.h"

#include "gatt.h"
#include "gapgattserver.h"
#include "gattservapp.h"

#include "simpleGATTprofile.h"

#include "includes.h" // custom header files

#define SDCP_IDLE_STATE 1 

#define DEBUG_SDCP 0


enum SDCP_STATES{
SdcpIdleState=0,
SdcpWaitPacketState,
SdcpCommandExecuteState,
SdcpSendAckState,
SdcpSendNackState,
};

enum SDCP_PACKETSTATES{
SdcpWaitSyncByteState=0,
SdcpWaitChecksumState,
SdcpWaitPacketLengthState,
SdcpReceivePduState,
};

#define SDCP_PACKETLENGTH_MAX 30
u8_t SdcpPacketBuffer[SDCP_PACKETLENGTH_MAX];

SDCP_CONTROL SdcpCtrl;

void SdcpPacketRx(u8_t Data);

//called in SimpleBLEPeripheral_Init in SimpleBLEPeripheral.c
void SdcpInit(void){ 
  SdcpCtrl.State=SdcpIdleState;
  SdcpCtrl.HasRxPacket=FALSE;
}

void SdcpStart(void){ 
  SdcpCtrl.State=SdcpWaitPacketState;
  SdcpCtrl.RxState=SdcpWaitSyncByteState;
}

// called in CustomSvc() in Custom.c
void SdcpSvc(void){
  u8_t Data;
  switch(SdcpCtrl.State){
    case SdcpIdleState: break; 
    case SdcpWaitPacketState: 
      if(Uart1RxBufferCheck()==BUFFER_EMPTY) return;
      Data=Uart1RxBufferGet();
#if(DEBUG_SDCP==1)     
DebugStringPrint("\n\rreceive byte ");
DebugU8Print(Data);
#endif
      SdcpPacketRx(Data);
      if(SdcpCtrl.HasRxPacket==FALSE) return;
      SdcpCtrl.HasRxPacket=FALSE;
      if(SdcpPacketBuffer[SDCP_PAYLOAD0]==SDCP_COMMAND_ACK){
        //todo:notify ack is in 
        DebugStringPrint("\n\rhas ack packet");
      }
      else if(SdcpPacketBuffer[SDCP_PAYLOAD0]==SDCP_COMMAND_NACK){
        //todo:notify nack is in 
        DebugStringPrint("\n\rhas nack packet");
      }
      else{
        SdcpCtrl.State=SdcpCommandExecuteState;
      }
      break;
    case SdcpCommandExecuteState: 
//#if(DEBUG_SDCP==1)     
DebugStringPrint("\n\rsend notification to central");
DebugBufferDump(&SdcpPacketBuffer[SDCP_PAYLOAD0],SdcpPacketBuffer[SDCP_HEADER_PAYLOADLENGTH]);
//#endif
      //todo:parse sdcp packet,
      //send packet down if packet comes from gateway...send sdcp packet to node central
      //simpleProfile_WriteAttrCB(....)

      //send packet up if packet comes from node central...send notification to gateway,if connected.
      //bStatus_t SimpleProfile_SetParameter( u8_t param, u8_t len, void *pValue )
      SimpleProfile_SetParameter(SIMPLEPROFILE_PARAM_CHAR3,SdcpPacketBuffer[SDCP_HEADER_PAYLOADLENGTH],&SdcpPacketBuffer[SDCP_PAYLOAD0]);
      SdcpCtrl.State=SdcpSendAckState;
      break;
    case SdcpSendAckState:  //send ack packet back to sdcp host     
      SdcpPacketBuffer[SDCP_HEADER_SYNC]=SDCP_HEADER_SYNCBYTE;
      SdcpPacketBuffer[SDCP_HEADER_CHECKSUM]=0xa4;
      SdcpPacketBuffer[SDCP_HEADER_PAYLOADLENGTH]=1;
      SdcpPacketBuffer[SDCP_PAYLOAD0]=SDCP_COMMAND_ACK;
      Uart1Write(SdcpPacketBuffer,4);
      SdcpCtrl.State=SdcpWaitPacketState;
      break;
    case SdcpSendNackState:  //send nack packet back to sdcp host
      SdcpPacketBuffer[SDCP_HEADER_SYNC]=SDCP_HEADER_SYNCBYTE;
      SdcpPacketBuffer[SDCP_HEADER_CHECKSUM]=0xa3;
      SdcpPacketBuffer[SDCP_HEADER_PAYLOADLENGTH]=1;
      SdcpPacketBuffer[SDCP_PAYLOAD0]=SDCP_COMMAND_NACK;
      Uart1Write(SdcpPacketBuffer,4);
      SdcpCtrl.State=SdcpWaitPacketState;
      break;
    default: break;
  }
}

void SdcpPacketTx(u8_t *pPacketData,u8_t Length){
  //check if legal packet
  //return;
  //Uart0Write(pPacketData,1);
  //Uart1Write(pPacketData,1);
}

// SdcpChecksumCalculate Calculate SDCP packets checksum
//2's complement to packet summation
u8_t SdcpChecksumCalculate(u8_t *pPacketData){
  u8_t i;
  u8_t Length;
  u8_t Checksum;
  
  Checksum=0;  
  Length = pPacketData[SDCP_HEADER_PAYLOADLENGTH]+ 3;
  for(i = 0; i < Length; i++) {
    if(i==SDCP_HEADER_CHECKSUM) continue; //skip checksum byte
    Checksum += *pPacketData;
    pPacketData ++;
  }
  Checksum=0x100-Checksum;
  return Checksum;
}

u8_t SdcpChecksumCheck(u8_t *pPacketData){
  u8_t i;
  u8_t Length;
  u8_t Checksum;
  
  Checksum=0;  
  Length = pPacketData[SDCP_HEADER_PAYLOADLENGTH]+ 3;
  for(i = 0; i < Length; i++) {
    Checksum += *pPacketData;
    pPacketData ++;
    //DebugStringPrint("\n\rChecksum ");
    //DebugU8Print(Checksum);
  }
  if(Checksum==0) return TRUE;
  else return FALSE;
}

void SdcpPacketRx(u8_t Data){
  switch(SdcpCtrl.RxState){
    case SdcpWaitSyncByteState: 
      if(Data!=SDCP_HEADER_SYNCBYTE) return;
      SdcpCtrl.Timer=250; //start to count time out
      SdcpPacketBuffer[0]=SDCP_HEADER_SYNCBYTE;
      SdcpCtrl.PacketIndex=1;
      SdcpCtrl.RxState=SdcpWaitChecksumState;
      break;
      
    case SdcpWaitChecksumState: 
      /*if(SdcpCtrl.Timer==0){ //time out
         SdcpCtrl.RxState=SdcpWaitSyncByteState;
         break;
      }*/
      SdcpPacketBuffer[1]=Data;
      SdcpCtrl.PacketIndex=2;
      SdcpCtrl.RxState=SdcpWaitPacketLengthState;
      break;
      
    case SdcpWaitPacketLengthState: 
      if(Data>23){ //length is too great
         SdcpCtrl.RxState=SdcpWaitSyncByteState;
         break;
      }
      /*if(SdcpCtrl.Timer==0){ //time out
         SdcpCtrl.RxState=SdcpWaitSyncByteState;
         break;
      }*/
      SdcpPacketBuffer[2]=Data;
      SdcpCtrl.PacketLength=Data+3;  //base 1
      if(SdcpCtrl.PacketLength==3){
        if(SdcpChecksumCheck(SdcpPacketBuffer)==TRUE){
          SdcpCtrl.HasRxPacket=1;
          //DebugStringPrint("\n\rchecksum success");
        }
        //else DebugStringPrint("\n\rchecksum fail");
        SdcpCtrl.RxState=SdcpWaitSyncByteState;
      }
      else{
        SdcpCtrl.PacketIndex=3;
        SdcpCtrl.RxState=SdcpReceivePduState;
      }
      break;
      
    case SdcpReceivePduState: 
      /*if(SdcpCtrl.Timer==0){ //time out
         SdcpCtrl.RxState=SdcpWaitSyncByteState;
         break;
      }*/
      SdcpPacketBuffer[SdcpCtrl.PacketIndex]=Data;
      SdcpCtrl.PacketIndex++;
      if(SdcpCtrl.PacketIndex==SdcpCtrl.PacketLength){
        //todo:check checksum
        if(SdcpChecksumCheck(SdcpPacketBuffer)==TRUE){
          SdcpCtrl.HasRxPacket=TRUE;
          //DebugStringPrint("\n\rchecksum success");
        }
        //else DebugStringPrint("\n\rchecksum fail");
        SdcpCtrl.RxState=SdcpWaitSyncByteState;
      }
      break;
    default: break;
  }

}
