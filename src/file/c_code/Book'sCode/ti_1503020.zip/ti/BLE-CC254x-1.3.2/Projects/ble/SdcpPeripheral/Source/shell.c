/*********************************************************
* Function: a simple shell for pic18f87j10
*
* File: shell.c
* Author: Book Chen
* Date 20090312
***********************************************************
*/
#include "hal_types.h"
//#include "hal_assert.h"
//#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
//#include "hal_uart.h"

#include "includes.h" // custom header files

#define ShellIdleState        0
#define ShellInitial0State    1
#define ShellInitial1State    2
#define ShellInitial2State    3
#define ShellWaitCommandState 4
#define ShellDispatchState    5
#define ShellExecuteState     6
#define ShellExecuteStopState 7

#define ShellExecuteIdleSubstate  0
#define ShellExecuteStartSubstate 1
#define ShellExecuteRunSubstate   2

// support shell commands
#define ItemInfo    0
#define ItemHelp    1
#define ItemTest0   2
#define ItemTest1   3
#define ItemTest2   4

const u8_t info[]="info";
const u8_t help[]="help";
const u8_t test0[]="t0";
const u8_t test1[]="t1";
const u8_t test2[]="t2";

const u8_t *ShellCommand[]={
info,
help,
test0,
test1,
test2,
(const u8_t *)0
};

SHELL_CONTROL ShellCtrl;

#define ARGUMENT_ARGV_MAX 10
#define ARGUMENT_INDEX_MAX 50
typedef struct{
  unsigned char State;
  unsigned char Status;
  unsigned char HasInput;
  unsigned char Insert;
  unsigned char *pArgv[ARGUMENT_ARGV_MAX];
  unsigned char Argc;
  unsigned char Index;
  unsigned char Get;
  unsigned char Put;
  unsigned char Data[ARGUMENT_INDEX_MAX];
}ARGUMENT_CONTROL;

#define DEBUG_SHELL_DUMP 0
#define DEBUG_SHELL_KEY  0
#define DEBUG_SHELL_DONE 0

#define ArgumentIdleState  0
#define ArgumentInitialState 1
#define ArgumentRxState    2

#define MeetEscKey  0x01
#define HasEscXkey  0x02
#define HasPageDown 0x04

ARGUMENT_CONTROL ArgumentCtrl;
//u32_t Address,Length;
u8_t LineByteCounter,LineCounter;
u8_t Buffer[3];

/*****************
* ShellInit:
* Initialize variables for shell and argument service
*******************/
void ShellInit(void){
  ShellArgumentInitial();
  ShellCtrl.Timer=0;
  ShellCtrl.State=ShellIdleState;
}

void ShellStart(void){
  ShellCtrl.State=ShellInitial0State;
}
/*****************
* ShellSvc:
* a simple shell using uart2
* accept and execute host command through rs232
* show debug message
*******************/
void ShellSvc(void){
  u8_t i;
  u8_t Argc;
  //uint16 j,k;
  //u8_t *pData;
  //u8_t **ppArgv;  // pointer of pArgv
  //void (*GotoStart)(void);

  switch(ShellCtrl.State){
    case ShellIdleState:
      break;
    case ShellInitial0State:
      ShellArgumentInitial();
      //if(SystemCtrl.Endian==MY_BIGENDIAN) DebugStringPrint("\n system is big endian");
      //else  DebugStringPrint("\nsystem is little endian");  //pic18 is little endian
      DebugStringPrint("\n\r*********");
      DebugStringPrint("\n\rHello,This is cc2541.");
      DebugStringPrint("\n\r*********");
      DebugStringPrint("\n\r$>");
      ShellCtrl.State=ShellInitial1State;
      break;
    case ShellInitial1State:
      ShellCtrl.State=ShellWaitCommandState;
      break;
    case ShellInitial2State:
      ShellArgumentSvc();
      break;
    case ShellWaitCommandState:
      ShellArgumentSvc();
      if(ShellArgumentStatusCheck()==TRUE) ShellCtrl.State=ShellDispatchState;
      break;
    case ShellDispatchState:
      Argc=ArgumentCtrl.Argc;
      //ppArgv=(unsigned char **)&ArgumentCtrl.pArgv;
      if(Argc>0){
        for(i=0;;i++){
          if(ShellCommand[i]==(u8_t *)0){
            DebugStringPrint("\ncommand not found");
            break;
          }
          if(SystemStringCompare((u8_t *)ArgumentCtrl.pArgv[0],(u8_t *)ShellCommand[i])==0){
            ShellCtrl.ExecuteItem=i;
            ShellCtrl.ExecuteState=ShellExecuteStartSubstate;
            ShellCtrl.State=ShellExecuteState;
            //ShellCtrl.State=ShellExecuteStopState;
            return;
          }
        }
      }
      DebugStringPrint("\n\r$>");
      ShellArgumentReset();
      ShellCtrl.State=ShellWaitCommandState;
      break;
    case ShellExecuteState:
      switch(ShellCtrl.ExecuteItem){
        case ItemInfo:
          switch(ShellCtrl.ExecuteState){
            case ShellExecuteIdleSubstate:
              ShellCtrl.State=ShellExecuteStopState;
              break;
            case ShellExecuteStartSubstate:
              DebugStringPrint("\n\rsystem infomation");
              DebugStringPrint("\n\rmcu: cc2541");
              DebugStringPrint("\n\rflash 256k");
              DebugStringPrint("\n\rsdram: 8k");
              ShellCtrl.ExecuteState=ShellExecuteIdleSubstate;
              break;
          }
          break;
        case ItemHelp:
          switch(ShellCtrl.ExecuteState){
            case ShellExecuteIdleSubstate:
              ShellCtrl.State=ShellExecuteStopState;
              break;
            case ShellExecuteStartSubstate:
              DebugStringPrint("\n\rcommand list:");
              DebugStringPrint("\n\rinfo");
              DebugStringPrint("\n\rhelp");
              ShellCtrl.ExecuteState=ShellExecuteRunSubstate;
              break;
            case ShellExecuteRunSubstate:
              ShellCtrl.ExecuteState=ShellExecuteIdleSubstate;
              break;
          }
          break;
        case ItemTest0:
          switch(ShellCtrl.ExecuteState){
            case ShellExecuteIdleSubstate:
              ShellCtrl.State=ShellExecuteStopState;
              break;
            case ShellExecuteStartSubstate: 
              Uart0StringTx("\n\rshow registers");
              Uart0StringTx("\n\rIEN0 ");
              DebugU8Print(IEN0);
              Uart0StringTx("\n\rIEN1 ");
              DebugU8Print(IEN1);
              Uart0StringTx("\n\rIRCON ");
              DebugU8Print(IRCON);
              Uart0StringTx("\n\rT1CTL ");
              DebugU8Print(T1CTL);
              Uart0StringTx("\n\rT1STAT ");
              DebugU8Print(T1STAT);
              Uart0StringTx("\n\rT1CC0H ");
              DebugU8Print(T1CC0H);
              Uart0StringTx("\n\rT1CC0L ");
              DebugU8Print(T1CC0L);
              ShellCtrl.ExecuteState=ShellExecuteRunSubstate;
              break;
            case ShellExecuteRunSubstate:    
              ShellCtrl.ExecuteState=ShellExecuteIdleSubstate;
              break;
          }
          break;
        case ItemTest1:
          switch(ShellCtrl.ExecuteState){
            case ShellExecuteIdleSubstate:
              ShellCtrl.State=ShellExecuteStopState;
              break;
            case ShellExecuteStartSubstate:      
              //make a sdcp packet for notification
              Uart1RxBufferPut(SDCP_HEADER_SYNCBYTE);  
              Uart1RxBufferPut(0x100-SDCP_HEADER_SYNCBYTE-5-13);  //15=3+1+2+3+4 
              Uart1RxBufferPut(0x05);
              Uart1RxBufferPut(SDCP_COMMAND_DATA); //SDCP_COMMAND_DATA=3
              Uart1RxBufferPut(0x01);
              Uart1RxBufferPut(0x02);
              Uart1RxBufferPut(0x03);
              Uart1RxBufferPut(0x04);
              ShellCtrl.ExecuteState=ShellExecuteRunSubstate;
              break;
            case ShellExecuteRunSubstate:
              ShellCtrl.ExecuteState=ShellExecuteIdleSubstate;
              break;
          }
          break;
        case ItemTest2:
          switch(ShellCtrl.ExecuteState){
            case ShellExecuteIdleSubstate:
              ShellCtrl.State=ShellExecuteStopState;
              break;
            case ShellExecuteStartSubstate:           
              Uart1RxBufferPut(SDCP_HEADER_SYNCBYTE);  
              Uart1RxBufferPut(0x100-SDCP_HEADER_SYNCBYTE-1-1);  
              Uart1RxBufferPut(0x01);
              Uart1RxBufferPut(0x01);
              ShellCtrl.ExecuteState=ShellExecuteRunSubstate;
              break;
            case ShellExecuteRunSubstate:
              ShellCtrl.ExecuteState=ShellExecuteIdleSubstate;
              break;
          }
          break;
        default:
          ShellCtrl.State=ShellExecuteStopState;
          break;
      }
      break;
    case ShellExecuteStopState:
      DebugStringPrint("\n\r$>");
      ShellArgumentReset();
      ShellCtrl.State=ShellWaitCommandState;
      break;
    default:
      break;
  }
}
/************
* ShellStatusCheck:
* check if shell runing 
*************/
BOOL ShellStatusCheck(void){
  if(ShellCtrl.State>=ShellWaitCommandState) return TRUE;
  else return FALSE;
}
/************
* ShellArgumentInitial:
* initialize variables used in argument service
* argument service is use to accept argument incoming from host through rs232 
*************/
void ShellArgumentInitial(void){
  ArgumentCtrl.Put=0;
  ArgumentCtrl.Index=0;
  ArgumentCtrl.Insert=FALSE;
  ArgumentCtrl.Argc=0;
  ArgumentCtrl.Status=0;
  ArgumentCtrl.HasInput=FALSE;
  ArgumentCtrl.State=ArgumentRxState;
}
/************
* ShellArgumentSvc:
* initialize variables used in argument service
* argument service is use to accept argument incoming from host through rs232 
*************/
void ShellArgumentSvc(void){
  unsigned char Data;

  switch(ArgumentCtrl.State){
    case ArgumentIdleState:
      break;
    case ArgumentRxState:
      if(Uart0RxBufferCheck()==BUFFER_EMPTY) return;
      Data=Uart0RxBufferGet();
      // process special keys
      if(Data==ASCII_ESC){
        ArgumentCtrl.Status=0;
        ArgumentCtrl.Status=MeetEscKey;
        return;
      }
      else if(ArgumentCtrl.Status==MeetEscKey){
        if(Data==0x5b){
          ArgumentCtrl.Status=HasEscXkey;
          return;
        }
        else{
          ArgumentCtrl.Status=0; // meet single esc key, not a special key
        }
      }
      else if(ArgumentCtrl.Status==HasEscXkey){
        switch(Data){
          case KEY_HOME:
            ShellArgumentHome();
            ArgumentCtrl.Status=0;
            return;
          case KEY_END:
            ShellArgumentEnd();
            ArgumentCtrl.Status=0;
            return;
          case KEY_PAGE_UP:
            ShellArgumentPageUp();
            ArgumentCtrl.Status=0;
            return;
          case KEY_PAGE_DOWN:
            ArgumentCtrl.Status=HasPageDown;
            return;
          case KEY_LEFT_ARROW:
            ShellArgumentArrowLeft();
            ArgumentCtrl.Status=0;
            return;
          case KEY_RIGHT_ARROW:
            ShellArgumentArrowRight();
            ArgumentCtrl.Status=0;
            return;
          case KEY_UP_ARROW:
            ShellArgumentArrowUp();
            ArgumentCtrl.Status=0;
            return;
          case KEY_DOWN_ARROW:
            ShellArgumentArrowDown();
            ArgumentCtrl.Status=0;
            return;
          default:
            ArgumentCtrl.Status=0;
            return; // skip this code no matter what it is
        }
        //ArgumentCtrl.Status=0;
      }
      else if(ArgumentCtrl.Status==HasPageDown){
        if(Data==0x4a){
          ShellArgumentPageDown();
          ArgumentCtrl.Status=0;
          return;
        }
        ArgumentCtrl.Status=0;
      }
      switch(Data){
        case  ASCII_NUL: // ^@
          break;
        case  ASCII_SOH: // ^A
          break;
        case  ASCII_STX: // ^B
          break;
        case  ASCII_ETX: // ^C
          break;
        case  ASCII_EOT: // ^D
          break;
        case  ASCII_ENQ: // ^E
          break;
        case  ASCII_ACK: // ^F
          break;
        case  ASCII_BEL: // ^G
          break;
        case  ASCII_BS:  // ^H
          ShellArgumentBs();
          //HidPs2KeyDispatch(Data);
          //GuiTextBufferPut(Data);
          break;
        case  ASCII_HT:  // ^I
          break;
        case  ASCII_LF:  // ^J
          break;
        case  ASCII_VT:  // ^K
          break;
        case  ASCII_FF:  // ^L
          break;
        case  ASCII_CR:  // ^M
          ShellArgumentKeyPut(Data);
          //HidPs2KeyDispatch(Data);
          //GuiTextBufferPut(Data);
          ShellArgumentParser();
          //ArgumentCtrl.Index=0;
          //ArgumentCtrl.Put=0;
          break;
        case  ASCII_SO:  // ^N
          break;
        case  ASCII_SI:  // ^O
          break;
        case  ASCII_DLE: // ^P
          break;
        case  ASCII_DC1: // ^Q
          break;
        case  ASCII_DC2: // ^R
          break;
        case  ASCII_DC3: // ^S
          break;
        case  ASCII_DC4: // ^T
          break;
        case  ASCII_NAK: // ^U
          break;
        case  ASCII_SYN: // ^V
          break;
        case  ASCII_ETB: // ^W
          break;
        case  ASCII_CAN: // ^X
          break;
        case  ASCII_EM:  // ^Y
          break;
        case  ASCII_SUB: // ^Z
          break;
        //case  ASCII_ESC: // ^[
        //  break;
        case  ASCII_FS:   /* ^\  */
          break;
        case  ASCII_GS:  // ^]
          break;
        case  ASCII_RS:  // ^^
          break;
        case  ASCII_US:  // ^_
          break;
        case  ASCII_DEL: //
          ShellArgumentDel();
          break;
        default:
          if((Data>=0x20)&&(Data<=0x7e)){
            ShellArgumentKeyPut(Data);
            //HidPs2KeyDispatch(Data);
            //GuiTextBufferPut(Data);
          }
          break;
      }
  }
}
/************
* ShellArgumentParser:
* find out arguments in string accepted through rs232 
*************/
#define ArgumentSearchState  0
#define ArgumentGoThroughState 1
#define ArgumentDoneState    2
void ShellArgumentParser(void){
  unsigned char Index;
  unsigned char State;
  //unsigned char Status;
  //unsigned char i;
  //unsigned char **ppArgv;
  //Status=0;

  Index=0;
  ArgumentCtrl.Argc=0;
  State=ArgumentSearchState;
  while(1){
    switch(State){
      case ArgumentSearchState:
        if(ArgumentCtrl.Data[Index]==0x20){;}     // " "
        else if(ArgumentCtrl.Data[Index]==0x0d){  // enter key
          ArgumentCtrl.Data[Index]=0;
          ArgumentCtrl.Data[Index+1]=0x0d;
          State=ArgumentDoneState;
        }
        else{
          ArgumentCtrl.pArgv[ArgumentCtrl.Argc]=&ArgumentCtrl.Data[Index];
          ArgumentCtrl.Argc++;
          State=ArgumentGoThroughState;
        }
        break;
      case ArgumentGoThroughState:
        if(ArgumentCtrl.Data[Index]==0x0d){
          ArgumentCtrl.Data[Index]=0;
          ArgumentCtrl.Data[Index+1]=0x0d;
          State=ArgumentDoneState;
        }
        else if(ArgumentCtrl.Data[Index]==0x20){
          ArgumentCtrl.Data[Index]=0;
          State=ArgumentSearchState;
        }
        break;
      case ArgumentDoneState:
        if(ArgumentCtrl.Put==250){ // too many input
          ShellArgumentReset();
          return;
        }
        ArgumentCtrl.HasInput=TRUE;
        return;
    }
    Index++;
  }
}
/************
* ShellArgumentStatusCheck
* find out arguments in string accepted through rs232 
*************/
u8_t ShellArgumentStatusCheck(void){
  if(ArgumentCtrl.HasInput==TRUE) return TRUE;
  else return FALSE;
}


/************
* ShellArgumentReset
* reset variables used in argument service
*************/
void ShellArgumentReset(void){
  ArgumentCtrl.Index=0;
  ArgumentCtrl.Put=0;
  ArgumentCtrl.Argc=0;
  ArgumentCtrl.HasInput=FALSE;
}

void ShellArgumentBs(void){
  unsigned char i;
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_bs");
  #endif
  if(ArgumentCtrl.Put==ArgumentCtrl.Index){
    if(ArgumentCtrl.Put==0){;}
    else{
      ArgumentCtrl.Put--;
      ArgumentCtrl.Index--;
    }
  }
  else{
    if(ArgumentCtrl.Index==0){;}
    else{
      ArgumentCtrl.Index--;
      ArgumentCtrl.Put--;
      i=ArgumentCtrl.Index;
      for(;i<=ArgumentCtrl.Put;i++){
        ArgumentCtrl.Data[i]=ArgumentCtrl.Data[i+1];
      }
    }
  }
}

void ShellArgumentDel(void){
  unsigned char i;
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_del");
  #endif
  if(ArgumentCtrl.Put==ArgumentCtrl.Index){;} // nothing to delete
  else{                       // xxxxyyyy -> xxxyyyy
     ArgumentCtrl.Put--;
     i=ArgumentCtrl.Index;
     for(;i<=ArgumentCtrl.Put;i++){
       ArgumentCtrl.Data[i]=ArgumentCtrl.Data[i+1];
     }
  }
}

void ShellArgumentKeyPut(unsigned char Data){
  unsigned char i;

  if(ArgumentCtrl.Put==ArgumentCtrl.Index){
    ArgumentCtrl.Data[ArgumentCtrl.Index]=Data;
    if(ArgumentCtrl.Put<250){
      ArgumentCtrl.Put++;
      ArgumentCtrl.Index++;
    }
  }
  else{
    if(Data==0x0d){
      ArgumentCtrl.Data[ArgumentCtrl.Put]=Data;
    }
    else{
      if(ArgumentCtrl.Insert==TRUE){
        i=ArgumentCtrl.Put;
        for(;i>=ArgumentCtrl.Index;i--){
          ArgumentCtrl.Data[i+1]=ArgumentCtrl.Data[i];
        }
        ArgumentCtrl.Data[ArgumentCtrl.Index]=Data;
        if(ArgumentCtrl.Put<250) ArgumentCtrl.Put++;
        ArgumentCtrl.Index++;
      }
      else{
        ArgumentCtrl.Data[ArgumentCtrl.Index]=Data;
        ArgumentCtrl.Index++;
      }
    }
  }
}

void ShellArgumentIns(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_ins");
  #endif
  //if(ArgumentCtrl.Insert==TRUE) ArgumentCtrl.Insert=FALSE;
  //else ArgumentCtrl.Insert=TRUE;
}

void ShellArgumentHome(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_home");
  #endif
  ArgumentCtrl.Index=0;
}

void ShellArgumentEnd(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_end");
  #endif
  ArgumentCtrl.Index=ArgumentCtrl.Put;
}

void ShellArgumentPageUp(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_page_up");
  #endif
}

void ShellArgumentPageDown(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_page_down");
  #endif
}

void ShellArgumentArrowUp(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_arrow_up");
  #endif
}

void ShellArgumentArrowDown(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_arrow_down");
  #endif
}

void ShellArgumentArrowLeft(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_arrow_left");
  #endif
  if(ArgumentCtrl.Index==0){;}
  else{
    ArgumentCtrl.Index--;
  }
}

void ShellArgumentArrowRight(void){
  #if(DEBUG_SHELL_KEY==1)
    DebugStringPrint("\n\r key_arrow_right");
  #endif
  if(ArgumentCtrl.Index==ArgumentCtrl.Put){;}
  else{
    if(ArgumentCtrl.Index<ArgumentCtrl.Put) ArgumentCtrl.Index++;
  }
}
