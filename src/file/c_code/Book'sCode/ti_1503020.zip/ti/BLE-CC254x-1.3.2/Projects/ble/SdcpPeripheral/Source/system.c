/**************
*description: system library
*
*author: Book Chen
*date:20140722
****************
*/

/*#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"
*/

#include "includes.h" // custom header files

enum System_States{
  SystemIdleState=0,
  SystemInitialState,
  SystemRunState,
};

SYSTEM_CONTROL SystemCtrl;

#if 0
void SystemInit (void){
  UN_UI EndianTest;

  EndianTest.uc[0]=0x55;
  EndianTest.uc[1]=0xaa;
  if(EndianTest.ui == 0x55aa) SystemCtrl.Endian=MY_BIGENDIAN;
  else SystemCtrl.Endian=MY_LITTLEENDIAN;
}
#endif

//SystemInit is called in main
void SystemInit(void){
  LedInit();
  Uart0Init(); //uart0 is for serial data communication protocal
  Uart0Open(); 
  Uart1Init(); //uart1 is for shell
  Uart1Open();
  I2cInit(); //I2c is for PMIC use. PMIC!? yes,PMIC!
  Timer1Init();
  Timer3Init();
  Timer4Init();
  SdcpInit(); //sdcp is brief of Serial Data Communication Protocal
  ShellInit();
  SystemCtrl.State=SystemIdleState;
}

//SystemStart is called in main
void SystemStart(void){ SystemCtrl.State=SystemInitialState; }

//SystemSvc is called in osal_start_system
void SystemSvc(void){
  switch(SystemCtrl.State){
    case SystemIdleState: break;
    case SystemInitialState: 
      SdcpStart();
      ShellStart(); 
      LedStart();
      SystemCtrl.State=SystemRunState; 
      break;
    case SystemRunState: //put service here.
      Uart0Svc();
      Uart1Svc();
      SdcpSvc();
      ShellSvc();
      LedSvc();
      //if(Timer1Ctrl.TimerU8==0){
      //  Timer1Ctrl.TimerU8=200;
        //Uart1CharTx('t');
      //}
      break;
    default: break;	
  }
}

void SystemMemoryCopy(u8_t *pSource,u8_t *pDestinaiton,u8_t Length){
  while(Length){
    *pDestinaiton=*pSource;
    pSource++;
    pDestinaiton++;
    Length--;
  }
}

u8_t SystemStringCompare(u8_t *pString1,u8_t *pString2){
  while(1){
    if(*pString1!=*pString2) return 1; //not the same
    if((*pString1==0)&&(*pString2==0)) return 0; //the same
    pString1++;
    pString2++;
  }
}






