/**************
*description: driver of uart1 
*
*author: Book Chen
*date:20140722
****************
*/
#include "includes.h"

//Parameter
UART0_CONTROL Uart0Ctrl;
//INT8U HasRxData;
//INT8U RxData;


//#define _TX_IER_ENABLE()    (_TX1IE=1)
//#define _TX_IER_DISABLE()    (_TX1IE=0)
//#define _TX_BUFFER             TXREG1
//#define _RC_BUFFER             RCREG1
//#define _TX_IER_ENABLE()    (UART0->IER |= UART_IER_THRE_IE)
//#define _RC_IER_ENABLE()    (UART0->IER |= (UART_IER_RDA_IE|UART_IER_RLS_IE))
#define _TX_IER_ENABLE()    (UART0->IER |= DRVUART_THREINT)
#define _RC_IER_ENABLE()    (UART0->IER |= (DRVUART_RDAINT|DRVUART_RLSINT))
#define _TX_IER_DISABLE()   (UART0->IER &= ~UART_IER_THRE_IE)
#define _TX_BUFFER          UART0->THR
#define _RC_BUFFER          UART0->RBR

//UART0_IRQHandler is an irq handler installed in vector table in startup.s
void UART0_IRQHandler(void){
    INT32U IntStatus;
    INT32U IntEnStatus;
    IntEnStatus = UART0->IER;
    IntStatus = UART0->ISR;
    //if((IntStatus & UART_ISR_RDA_IS) || (IntStatus & UART_ISR_RTO_IS))
    if(IntStatus & UART_ISR_RDA_IS && (IntEnStatus & UART_IER_RDA_IE)) Uart0RxIsr();
    if (IntStatus & UART_ISR_THRE_IS && (IntEnStatus & UART_ISR_THRE_IS)) Uart0TxIsr();
}

void UART0init(void)  {
    STR_UART_T param;    

    //HasRxData=0;
    Uart0Ctrl.RcBuffer.Get=0; 
    Uart0Ctrl.RcBuffer.Put=0; 
    Uart0Ctrl.TxBuffer.Get=0; 
    Uart0Ctrl.TxBuffer.Put=0; 
    Uart0Ctrl.UartTxTransmit=0;
    
    //choose uart  high speed crystal
    SYS_SelectIPClockSource_1(CLK_CLKSEL1_UART_MASK, CLK_CLKSEL1_UART_HXT); 

    // Set UART0 Pin 
    //MFP_FULL_UART0_TO_PORTB();
    MFP_UART0_TO_PORTB();
    
    param.u32BaudRate    = 115200;
    param.u32cDataBits    = DRVUART_DATABITS_8;
    param.u32cStopBits    = DRVUART_STOPBITS_1;
    param.u32cParity    = DRVUART_PARITY_NONE;
    param.u32cRxTriggerLevel= DRVUART_FIFO_1BYTES;
    param.u8TimeOut        = 0;
    param.u8EnableDiv16    = DISABLE;

    //config uart1 
    if(UART_Init(UART0,&param) != E_SUCCESS) return;

    //Clean RCREG Buffer
    //r = RCREG;
    //r = RCREG;

    //enable uart1 interrupt
    //DRVUART_RLSINT is receive line status interrupt
    //DRVUART_RDAINT is receive data available interrupt
    //UART_EnableInt(UART0, (DRVUART_RLSINT | DRVUART_RDAINT));
    //UART_EnableInt(UART0, (DRVUART_THREINT | DRVUART_RDAINT));
    UART0->IER = DRVUART_RDAINT;
    //UART0->IER = DRVUART_RLSINT | DRVUART_RDAINT;
    //UART0->IER = DRVUART_THREINT | DRVUART_RDAINT;
    NVIC_EnableIRQ(UART0_IRQn); 
}

            
void Uart0Svc(void){
    //while(Uart0RxBufferCheck()!=BUFFER_EMPTY){
    //    Uart0TxBufferPut(Uart0RxBufferGet());
    //}
    if(Uart0Ctrl.UartTxTransmit==1) return;
    if(Uart0TxBufferCheck()==BUFFER_EMPTY) return;
    
    /* Enable Tx Empty Interrupt. (Trigger first one) */
    //_TX_IER_ENABLE();    //Enable Tx interrupt
    Uart0Ctrl.UartTxTransmit=1;
    UART0->IER |= DRVUART_THREINT ;
}

void Uart0TxIsr(void){
    if(Uart0TxBufferCheckIsr()==BUFFER_EMPTY){
        Uart0Ctrl.UartTxTransmit=0;
        UART0->IER &= ~DRVUART_THREINT ;
    }
    else _TX_BUFFER=Uart0TxBufferGet();      
}

void Uart0RxIsr(void){
    INT8U RxData;
    RxData=_RC_BUFFER;
    if(Uart0RxBufferCheckIsr()!=BUFFER_FULL) Uart0RxBufferPut(RxData);
}



void Uart0BufferReset(void){
    Uart0Ctrl.TxBuffer.Get=0;
    Uart0Ctrl.TxBuffer.Put=0;
    Uart0Ctrl.RcBuffer.Get=0;
    Uart0Ctrl.RcBuffer.Put=0;
    Uart0Ctrl.UartTxTransmit=0;    
}

INT8U Uart0TxBufferCheck(void){
    if(Uart0Ctrl.TxBuffer.Put!=Uart0Ctrl.TxBuffer.Get)
    {
        if(Uart0Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart0Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart0Ctrl.TxBuffer.Put+1)==Uart0Ctrl.TxBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

INT8U Uart0TxBufferCheckIsr(void){
    if(Uart0Ctrl.TxBuffer.Put!=Uart0Ctrl.TxBuffer.Get)
    {
        if(Uart0Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart0Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart0Ctrl.TxBuffer.Put+1)==Uart0Ctrl.TxBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

void Uart0TxBufferPut(INT8U ucData){
    if(Uart0TxBufferCheck()==BUFFER_FULL) return;
    if(Uart0Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
    {
        Uart0Ctrl.TxBuffer.Data[UART_MAX_BUFFER_SIZE-1]=ucData;
        Uart0Ctrl.TxBuffer.Put=0;
    }
    else
    {
        Uart0Ctrl.TxBuffer.Data[Uart0Ctrl.TxBuffer.Put]=ucData;
        Uart0Ctrl.TxBuffer.Put++;
    }
}
INT8U Uart0TxBufferGet(void)
{
    INT8U Data;

    if(Uart0TxBufferCheck()==BUFFER_EMPTY) return 0;
    if(Uart0Ctrl.TxBuffer.Get==(UART_MAX_BUFFER_SIZE-1))
    {
        Data=Uart0Ctrl.TxBuffer.Data[UART_MAX_BUFFER_SIZE-1];
        Uart0Ctrl.TxBuffer.Get=0;
    }
    else
    {
        Data=Uart0Ctrl.TxBuffer.Data[Uart0Ctrl.TxBuffer.Get];
        Uart0Ctrl.TxBuffer.Get++;
    }
    return Data;
}

INT8U Uart0RxBufferCheck(void)
{
    if(Uart0Ctrl.RcBuffer.Put!=Uart0Ctrl.RcBuffer.Get)
    {
        if(Uart0Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart0Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart0Ctrl.RcBuffer.Put+1)==Uart0Ctrl.RcBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

INT8U Uart0RxBufferCheckIsr(void)
{
    if(Uart0Ctrl.RcBuffer.Put!=Uart0Ctrl.RcBuffer.Get)
    {
        if(Uart0Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart0Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart0Ctrl.RcBuffer.Put+1)==Uart0Ctrl.RcBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

void Uart0RxBufferPut(INT8U Data)
{
    if(Uart0RxBufferCheck()==BUFFER_FULL) return;
    if(Uart0Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
    {
        Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Put]=Data;
        Uart0Ctrl.RcBuffer.Put=0;
    }
    else
    {
        Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Put]=Data;
        Uart0Ctrl.RcBuffer.Put++;
    }
}

INT8U Uart0RxBufferGet(void)
{
    INT8U Data;

    if(Uart0RxBufferCheck()==BUFFER_EMPTY) return 0;
    if(Uart0Ctrl.RcBuffer.Get==(UART_MAX_BUFFER_SIZE-1))
    {
        Data=Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Get];
        Uart0Ctrl.RcBuffer.Get=0;
    }
    else
    {
        Data=Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Get];
        Uart0Ctrl.RcBuffer.Get++;
    }
    return Data;
}


void Uart0CharTx(char ucData)
{
    // If buffer is full , sent char right now.
    while(Uart0TxBufferCheck()==BUFFER_FULL) Uart0Svc();
    Uart0TxBufferPut(ucData);
    Uart0Svc();
}

void Uart0StringTx(char *pString) {
    while(*pString!=0) Uart0CharTx(*pString++);
}
