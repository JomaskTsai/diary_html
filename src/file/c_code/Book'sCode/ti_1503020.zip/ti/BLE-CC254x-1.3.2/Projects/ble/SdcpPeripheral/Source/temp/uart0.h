#ifndef UART0_H
#define	UART0_H

#define UART_MAX_BUFFER_SIZE	100
#define BUFFER_EMPTY		0
#define BUFFER_NOT_EMPTY	1
#define BUFFER_FULL		2

typedef struct{
    INT8U Put;
    INT8U Get;
    INT8U Data[UART_MAX_BUFFER_SIZE];
}UART0_BUFFER_CONTROL;

typedef struct{
    INT8U  UartTxTransmit;
    UART0_BUFFER_CONTROL TxBuffer;
    UART0_BUFFER_CONTROL RcBuffer;
}UART0_CONTROL;

//@ 	Brief	
//@	UART0 Initial Process

void UART0init(void);
void UART0InterruptSetting(void);

//@ 	Brief	
//@	UART0 Parameter

void Uart0BufferReset(void);
INT8U Uart0TxBufferCheck(void);
INT8U Uart0TxBufferCheckIsr(void);
void Uart0TxBufferPut(INT8U ucData);
INT8U Uart0TxBufferGet(void);
INT8U Uart0RxBufferCheck(void);
INT8U Uart0RxBufferCheckIsr(void);
void Uart0RxBufferPut(INT8U Data);
INT8U Uart0RxBufferGet(void);

//@ 	Brief	
//@	UART0 Tx/RX Application

void Uart0Svc(void);
void Uart0CharTx(char ucData);
void Uart0StringTx(char *pString);
void Uart0TxIsr(void);
void Uart0RxIsr(void);

//@ 	Brief	
//@	UART0 Interrupt Application

void Uart0TxIsr(void);
void Uart0RxIsr(void);
void Uart0RxFinishIsr(void);

#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif

#endif

