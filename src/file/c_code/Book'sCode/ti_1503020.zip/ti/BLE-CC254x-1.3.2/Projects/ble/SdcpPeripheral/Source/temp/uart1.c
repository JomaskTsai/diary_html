/**************
*description: driver of uart1 
*
*author: Book Chen
*date:20140722
****************
*/
#include "includes.h"

//Parameter
UART1_CONTROL Uart1Ctrl;
//INT8U HasRxData;
//INT8U RxData;


//#define _TX_IER_ENABLE()    (_TX1IE=1)
//#define _TX_IER_DISABLE()    (_TX1IE=0)
//#define _TX_BUFFER             TXREG1
//#define _RC_BUFFER             RCREG1
//#define _TX_IER_ENABLE()    (UART1->IER |= UART_IER_THRE_IE)
//#define _RC_IER_ENABLE()    (UART1->IER |= (UART_IER_RDA_IE|UART_IER_RLS_IE))
#define _TX_IER_ENABLE()    (UART1->IER |= DRVUART_THREINT)
#define _RC_IER_ENABLE()    (UART1->IER |= (DRVUART_RDAINT|DRVUART_RLSINT))
#define _TX_IER_DISABLE()   (UART1->IER &= ~UART_IER_THRE_IE)
#define _TX_BUFFER          UART1->THR
#define _RC_BUFFER          UART1->RBR

void UART1_IRQHandler(void){
    INT32U IntStatus;
    INT32U IntEnStatus;
    IntEnStatus = UART1->IER;
    IntStatus = UART1->ISR;
    //if((IntStatus & UART_ISR_RDA_IS) || (IntStatus & UART_ISR_RTO_IS))
    if(IntStatus & UART_ISR_RDA_IS && (IntEnStatus & UART_IER_RDA_IE)) Uart1RxIsr();
    if (IntStatus & UART_ISR_THRE_IS && (IntEnStatus & UART_ISR_THRE_IS)) Uart1TxIsr();
}

void UART1init(void)  {
    STR_UART_T param;    

    //HasRxData=0;
    Uart1Ctrl.RcBuffer.Get=0; 
    Uart1Ctrl.RcBuffer.Put=0; 
    Uart1Ctrl.TxBuffer.Get=0; 
    Uart1Ctrl.TxBuffer.Put=0; 
    Uart1Ctrl.UartTxTransmit=0;
    
    //choose uart  high speed crystal
    SYS_SelectIPClockSource_1(CLK_CLKSEL1_UART_MASK, CLK_CLKSEL1_UART_HXT); 

    // Set UART1 Pin 
    //MFP_FULL_UART1_TO_PORTB();
    MFP_UART1_TO_PORTA();
    
    param.u32BaudRate    = 115200;
    param.u32cDataBits    = DRVUART_DATABITS_8;
    param.u32cStopBits    = DRVUART_STOPBITS_1;
    param.u32cParity    = DRVUART_PARITY_NONE;
    param.u32cRxTriggerLevel= DRVUART_FIFO_1BYTES;
    param.u8TimeOut        = 0;
    param.u8EnableDiv16    = DISABLE;

    //config uart1 
    if(UART_Init(UART1,&param) != E_SUCCESS) return;

    //Clean RCREG Buffer
    //r = RCREG;
    //r = RCREG;

    //enable uart1 interrupt
    //DRVUART_RLSINT is receive line status interrupt
    //DRVUART_RDAINT is receive data available interrupt
    //UART_EnableInt(UART1, (DRVUART_RLSINT | DRVUART_RDAINT));
    //UART_EnableInt(UART1, (DRVUART_THREINT | DRVUART_RDAINT));
    UART1->IER = DRVUART_RDAINT;
    //UART1->IER = DRVUART_RLSINT | DRVUART_RDAINT;
    //UART1->IER = DRVUART_THREINT | DRVUART_RDAINT;
    NVIC_EnableIRQ(UART1_IRQn); 
}

            
void Uart1Svc(void){
    //while(Uart1RxBufferCheck()!=BUFFER_EMPTY){
    //    Uart1TxBufferPut(Uart1RxBufferGet());
    //}
    if(Uart1Ctrl.UartTxTransmit==1) return;
    if(Uart1TxBufferCheck()==BUFFER_EMPTY) return;
    
    /* Enable Tx Empty Interrupt. (Trigger first one) */
    //_TX_IER_ENABLE();    //Enable Tx interrupt
    Uart1Ctrl.UartTxTransmit=1;
    UART1->IER |= DRVUART_THREINT ;
}

void Uart1TxIsr(void){
    if(Uart1TxBufferCheckIsr()==BUFFER_EMPTY){
        Uart1Ctrl.UartTxTransmit=0;
        UART1->IER &= ~DRVUART_THREINT ;
    }
    else _TX_BUFFER=Uart1TxBufferGet();      
}

void Uart1RxIsr(void){
    INT8U RxData;
    RxData=_RC_BUFFER;
    if(Uart1RxBufferCheckIsr()!=BUFFER_FULL) Uart1RxBufferPut(RxData);
}



void Uart1BufferReset(void){
    Uart1Ctrl.TxBuffer.Get=0;
    Uart1Ctrl.TxBuffer.Put=0;
    Uart1Ctrl.RcBuffer.Get=0;
    Uart1Ctrl.RcBuffer.Put=0;
    Uart1Ctrl.UartTxTransmit=0;    
}

INT8U Uart1TxBufferCheck(void){
    if(Uart1Ctrl.TxBuffer.Put!=Uart1Ctrl.TxBuffer.Get)
    {
        if(Uart1Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart1Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart1Ctrl.TxBuffer.Put+1)==Uart1Ctrl.TxBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

INT8U Uart1TxBufferCheckIsr(void){
    if(Uart1Ctrl.TxBuffer.Put!=Uart1Ctrl.TxBuffer.Get)
    {
        if(Uart1Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart1Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart1Ctrl.TxBuffer.Put+1)==Uart1Ctrl.TxBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

void Uart1TxBufferPut(INT8U ucData){
    if(Uart1TxBufferCheck()==BUFFER_FULL) return;
    if(Uart1Ctrl.TxBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
    {
        Uart1Ctrl.TxBuffer.Data[UART_MAX_BUFFER_SIZE-1]=ucData;
        Uart1Ctrl.TxBuffer.Put=0;
    }
    else
    {
        Uart1Ctrl.TxBuffer.Data[Uart1Ctrl.TxBuffer.Put]=ucData;
        Uart1Ctrl.TxBuffer.Put++;
    }
}
INT8U Uart1TxBufferGet(void)
{
    INT8U Data;

    if(Uart1TxBufferCheck()==BUFFER_EMPTY) return 0;
    if(Uart1Ctrl.TxBuffer.Get==(UART_MAX_BUFFER_SIZE-1))
    {
        Data=Uart1Ctrl.TxBuffer.Data[UART_MAX_BUFFER_SIZE-1];
        Uart1Ctrl.TxBuffer.Get=0;
    }
    else
    {
        Data=Uart1Ctrl.TxBuffer.Data[Uart1Ctrl.TxBuffer.Get];
        Uart1Ctrl.TxBuffer.Get++;
    }
    return Data;
}

INT8U Uart1RxBufferCheck(void)
{
    if(Uart1Ctrl.RcBuffer.Put!=Uart1Ctrl.RcBuffer.Get)
    {
        if(Uart1Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart1Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart1Ctrl.RcBuffer.Put+1)==Uart1Ctrl.RcBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

INT8U Uart1RxBufferCheckIsr(void)
{
    if(Uart1Ctrl.RcBuffer.Put!=Uart1Ctrl.RcBuffer.Get)
    {
        if(Uart1Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
        {
            if(Uart1Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
        else
        {
            if((Uart1Ctrl.RcBuffer.Put+1)==Uart1Ctrl.RcBuffer.Get) return BUFFER_FULL;
            else return BUFFER_NOT_EMPTY;
        }
    }
    else return BUFFER_EMPTY;
}

void Uart1RxBufferPut(INT8U Data)
{
    if(Uart1RxBufferCheck()==BUFFER_FULL) return;
    if(Uart1Ctrl.RcBuffer.Put==(UART_MAX_BUFFER_SIZE-1))
    {
        Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Put]=Data;
        Uart1Ctrl.RcBuffer.Put=0;
    }
    else
    {
        Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Put]=Data;
        Uart1Ctrl.RcBuffer.Put++;
    }
}

INT8U Uart1RxBufferGet(void)
{
    INT8U Data;

    if(Uart1RxBufferCheck()==BUFFER_EMPTY) return 0;
    if(Uart1Ctrl.RcBuffer.Get==(UART_MAX_BUFFER_SIZE-1))
    {
        Data=Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Get];
        Uart1Ctrl.RcBuffer.Get=0;
    }
    else
    {
        Data=Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Get];
        Uart1Ctrl.RcBuffer.Get++;
    }
    return Data;
}


void Uart1CharTx(char ucData)
{
    // If buffer is full , sent char right now.
    while(Uart1TxBufferCheck()==BUFFER_FULL) Uart1Svc();
    Uart1TxBufferPut(ucData);
    Uart1Svc();
}

void Uart1StringTx(char *pString) {
    while(*pString!=0) Uart1CharTx(*pString++);
}


     
/*
void Uart1Svc0(void)
{
    if(Uart1Ctrl.UartTxTransmit==1) return;
    if(HasRxData==0) return;

    //if(Uart1TxBufferCheck()==BUFFER_EMPTY) return;

    // Enable Tx Empty Interrupt. (Trigger first one) 
    //_TX_IER_ENABLE();    //Enable Tx interrupt
    UART1->IER |= DRVUART_THREINT ;
    Uart1Ctrl.UartTxTransmit=1;
    
}

void Uart1TxIsr0(void)
{
//    if(Uart1TxBufferCheck()==BUFFER_EMPTY)
//    {
//        Uart1Ctrl.UartTxTransmit=0;
//        _TX_IER_DISABLE();
//    }
    //else _TX_BUFFER='a'; //_T
//    else _TX_BUFFER=Uart1TxBufferGet();                      
  HasRxData=0;
  Uart1Ctrl.UartTxTransmit=0;
  _TX_BUFFER= RxData;
  UART1->IER &= ~DRVUART_THREINT ;            //disable  uart 1 tx interrupt        
}

void Uart1RxIsr0(void)
{
    //Uart1RxBufferPut(_RC_BUFFER);
    //_TX_BUFFER=    _RC_BUFFER ;
    RxData  =   _RC_BUFFER ;
    HasRxData=1;
}
*/


