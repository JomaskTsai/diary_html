#ifndef UART1_H
#define	UART1_H

#define UART_MAX_BUFFER_SIZE	100
#define BUFFER_EMPTY		0
#define BUFFER_NOT_EMPTY	1
#define BUFFER_FULL		2

typedef struct{
    INT8U Put;
    INT8U Get;
    INT8U Data[UART_MAX_BUFFER_SIZE];
}UART1_BUFFER_CONTROL;

typedef struct{
    INT8U  UartTxTransmit;
    UART1_BUFFER_CONTROL TxBuffer;
    UART1_BUFFER_CONTROL RcBuffer;
}UART1_CONTROL;


//@ 	Brief	
//@	UART1 Initial Process
void UART1init(void);
void UART1InterruptSetting(void);

//@ 	Brief	
//@	UART1 Parameter
void Uart1BufferReset(void);
INT8U Uart1TxBufferCheck(void);
INT8U Uart1TxBufferCheckIsr(void);
void Uart1TxBufferPut(INT8U ucData);
INT8U Uart1TxBufferGet(void);
INT8U Uart1RxBufferCheck(void);
INT8U Uart1RxBufferCheckIsr(void);
void Uart1RxBufferPut(INT8U Data);
INT8U Uart1RxBufferGet(void);

//@ 	Brief	
//@	UART1 Tx/RX Application

void Uart1Svc(void);
void Uart1CharTx(char ucData);
void Uart1StringTx(char *pString);
void Uart1TxIsr(void);
void Uart1RxIsr(void);

//@ 	Brief	
//@	UART1 Interrupt Application

void Uart1TxIsr(void);
void Uart1RxIsr(void);
void Uart1RxFinishIsr(void);

#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif

#endif

