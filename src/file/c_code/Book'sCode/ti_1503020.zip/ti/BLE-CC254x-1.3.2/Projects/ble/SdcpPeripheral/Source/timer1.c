/****************************
*project: bluetooth low energy local network
*function: driver of cc2541 timer 1
*timer1 has 5 operation mode. i use modulo mode here.
*free run mode..0->0xffff->0->0xffff....
*channel mode..use timer1 as a counter
*up down mode..(up count)0->1->0xffff->(down count)0xfffe->0->1->0xffff->0xfffe...
*modulo mode..0->[T1CC0]->0->[T1CC0]...
*
*author: book chen
*file: timer1.c
*****************************
*/
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"

#include "includes.h" // custom header files

TIMER1_CONTROL Timer1Ctrl;

void Timer1Init(void){
  T1CTL=0x02;    //frequency=Fsys/1,modulo mode
  T1CTL=0x01;    //frequency=Fsys/1,free run mode
  T1CTL=0x00;    //frequency=Fsys/1,timer usupend
  T1CCTL0=0x40;  //enable timer 0 interrupt,CMP[2:0]=110 reserved,comapre mode 
  T1CC0H=0x24;   //62500=0xf424
  T1CC0L=0xF4;   //62500=0xf424
  T1CCTL1=0x00;  //enable timer 0 interrupt,CMP[2:0]=110 reserved,comapre mode 
  T1CCTL2=0x00;  //enable timer 0 interrupt,CMP[2:0]=110 reserved,comapre mode 
  T1CCTL3=0x00;  //enable timer 0 interrupt,CMP[2:0]=110 reserved,comapre mode 
  T1CCTL4=0x00;  //enable timer 0 interrupt,CMP[2:0]=110 reserved,comapre mode 
  TIMIF|=0x40;   //Timer 1 overflow interrupt mask=1. enable timer interrupt 
  T1IE=1;        //IEN1.1
  //T1CTL=0x02;    //frequency=Fsys/1,modulo mode
  T1CTL=0x01;    //frequency=Fsys/1,free run mode
  Timer1Ctrl.HasTimerInterrupt=0;
}

//define timer 1 interrupt service routine
//IRCON.T1IF is cleared when cpu vectors to T1_VECTOR isr
HAL_ISR_FUNCTION( Timer1Isr, T1_VECTOR )
{
  HAL_ENTER_ISR();
  //Timer1Ctrl.HasTimerInterrupt=1;
  //todo: decrease timer value
  if(T1STAT&0x20){ //T1STAT.OVFIF is bit 5
    T1STAT &= ~0x20;
    if(Timer1Ctrl.TimerU8) Timer1Ctrl.TimerU8--;
    if(SdcpCtrl.Timer) SdcpCtrl.Timer--;
  }
  HAL_EXIT_ISR();
}
