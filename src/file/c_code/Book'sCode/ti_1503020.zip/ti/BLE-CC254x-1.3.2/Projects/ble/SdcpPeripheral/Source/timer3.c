/****************************
*project: bluetooth low energy local network
*function: driver of cc2541 timer 3
*
*author: book chen
*file: timer1.c
*****************************
*/
#include "hal_types.h"
#include "ioCC254x_bitdef.h" //this header file is copied from another example code project
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"

#include "includes.h" // custom header files

TIMER3_CONTROL Timer3Ctrl;

void Timer3Init(void){
  //CLKCONCMD = (CLKCONCMD & ~CLKCON_TICKSPD) | CLKCON_TICKSPD_250K;  //tick clock=250k
  //config timer 3
  //timer 3 clock=250k/128 ~ 2khz,free run mode,enable overflow interrupt,clear counter
  //T3CTL = T3CTL_DIV_128 | T3CTL_MODE_FREERUN | T3CTL_OVFIM | T3CTL_CLR | T3CTL_START;
  T3CTL = T3CTL_DIV_128 | T3CTL_MODE_FREERUN | T3CTL_OVFIM | T3CTL_CLR ;
  //EA = 1;
  T3IE = 1; //enable timer 3 interrupt
  T3CTL |= T3CTL_START;
  
  Timer3Ctrl.TimerU16=100;
}

//define timer 1 interrupt service routine
//IRCON.T1IF is cleared when cpu vectors to T3_VECTOR isr
HAL_ISR_FUNCTION( Timer3Isr, T3_VECTOR )
{
  HAL_ENTER_ISR();
  T3OVFIF = 0;
  T3IF = 0;
  if(Timer3Ctrl.TimerU16) Timer3Ctrl.TimerU16--;
  HAL_EXIT_ISR();
}
