/****************************
*project: bluetooth low energy local network
*function: driver of cc2541 timer 4
*
*author: book chen
*file: timer1.c
*****************************
*/
#include "hal_types.h"
#include "ioCC254x_bitdef.h" //this header file is copied from another example code project
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"

#include "includes.h" // custom header files

TIMER4_CONTROL Timer4Ctrl;

void Timer4Init(void){
  //CLKCONCMD = (CLKCONCMD & ~CLKCON_TICKSPD) | CLKCON_TICKSPD_250K;   //tick clock=250k
  //config timer 3
  //Timer 4 has priority over Timer 1. 
  //P2SEL |= P2SEL_PRI1P1;
  //PERCFG &= ~PERCFG_T4CFG; // Select Timer 4 pin location as alternative 1
  //T4CTL = T4CTL_DIV_128 | T4CTL_MODE_FREERUN | T4CTL_OVFIM | T4CTL_CLR | T4CTL_START;
  T4CTL = T4CTL_DIV_128 | T4CTL_MODE_FREERUN | T4CTL_OVFIM | T4CTL_CLR ;
  //EA = 1;
  T4IE = 1;
  T4CTL |= T4CTL_START ;
  
  Timer4Ctrl.TimerU16=100;
}

//define timer 1 interrupt service routine
//IRCON.T1IF is cleared when cpu vectors to T1_VECTOR isr
HAL_ISR_FUNCTION( Timer4Isr, T4_VECTOR )
{
  HAL_ENTER_ISR();
  T4OVFIF = 0;
  T4IF = 0;
  if(Timer4Ctrl.TimerU16) Timer4Ctrl.TimerU16--;
  HAL_EXIT_ISR();
}
