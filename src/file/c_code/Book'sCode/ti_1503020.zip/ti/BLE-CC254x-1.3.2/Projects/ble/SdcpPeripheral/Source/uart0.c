/****************************
*project: bluetooth low energy local network
*function: BLE peripheral using SPP profile
*driver for cc2541 uart 0
*uart0 is for shell & debug use
*
*author: book chen
*file: uart0.c
*****************************
*/
#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"

#include "includes.h"  // custom header files

UART0_CONTROL Uart0Ctrl;

void Uart0Init(void){
  //Port 2 Direction and Port 0 Peripheral Priority Control
  //priority of P0 peripheral is 1st USART0,2nd USART1,3rd TIMER
  //reference to 7.11 I/O Registers,cc254x_userguide.pdf
  P2DIR &= ~0xc0;  //set PRIP0[1:0]=00
  PERCFG &= ~0x01;  //config uart 0 on P0..PERCFG (0xF1) �V Peripheral Control
  //PERCFG |= 0x02 //config uart 1 on P1..PERCFG (0xF1) �V Peripheral Control..in uart1.c
  P0SEL  |= 0x0c;  //enable peripheral function on p0.2(uart0 rx) & p0.3(uart0 tx)
  
  APCFG &= ~0xc0;  //diable analog function of p0.2 & p0.3..
                   //make sure uart and adc do not conflict. 
                       
  U0CSR = 0x80;    //enable uart mode,uart rx disable            
  //U0CSR = 0x84;    //enable uart mode,uart rx enable
  
  U0UCR = 0x80;    //flush unit
                   //n.8.1,low stop bit,low start bit
                   
  Uart0Ctrl.State=0;
  Uart0Ctrl.Timer=0;
  Uart0Ctrl.UartTxTransmit=FALSE;
  Uart0Ctrl.RcBuffer.Get=0; 
  Uart0Ctrl.RcBuffer.Put=0; 
  Uart0Ctrl.TxBuffer.Get=0; 
  Uart0Ctrl.TxBuffer.Put=0; 
}


void Uart0Open(void){
  //config baudrate
  
  #if (UART0_BAUDRATE==9600)
    U0BAUD=59;
    U0GCR=8;
  #elif (UART0_BAUDRATE==19200)
    U0BAUD=59;
    U0GCR=9;
  #elif (UART0_BAUDRATE==38400)
    U0BAUD=59;
    U0GCR=10;
  #elif (UART0_BAUDRATE==57600)
    U0BAUD=216;
    U0GCR=10;
  #elif (UART0_BAUDRATE==115200)
    U0BAUD=216;
    U0GCR=11;
  #endif

  U0UCR=0x02; //n.8.1,high stop bit,low start bit..default
  URX0IE=1; //enable UART 0 recevie interrupt
  UTX0IF=1; //Prime the ISR pump..need?
  U0CSR=0x80+0x40; //uart mode + receive enable
}

void Uart0Svc(void){
    if(Uart0Ctrl.UartTxTransmit==1) return;
    if(Uart0TxBufferCheck()==BUFFER_EMPTY) return;
    Uart0Ctrl.UartTxTransmit=1;
    IEN2 |= 0x04; // Enable Tx Empty Interrupt. (Trigger first one) 
}

void Uart0Write(uint8 *pData,uint8 Length){
  if(Length==0) return;
  while(Length){
    while(Uart0TxBufferCheck()==BUFFER_FULL) Uart0Svc();
    Uart0TxBufferPut(*pData);
    Length--;
    pData++;
  }
  Uart0Svc();
}

/*************
* interrupt service routine for uart0
**************/
HAL_ISR_FUNCTION( halUart0RxIsr, URX0_VECTOR )
{
  HAL_ENTER_ISR();
  Uart0RxBufferPut(U0DBUF);
  HAL_EXIT_ISR();
}

HAL_ISR_FUNCTION( halUart0TxIsr, UTX0_VECTOR )
{
  HAL_ENTER_ISR();
  if(Uart0TxBufferCheckIsr()!=BUFFER_EMPTY){
    UTX0IF=0; //clear interrupt flag
    U0DBUF=Uart0TxBufferGet(); 
  }
  else {
    Uart0Ctrl.UartTxTransmit=FALSE;
    IEN2 &= ~0x04; //UTX1IE; disable uart0 tx interrupt	
  }
  HAL_EXIT_ISR(); 
}

/*************
* buffer control library for uart0
**************/
void Uart0BufferReset(void){
  Uart0Ctrl.TxBuffer.Get=0;
  Uart0Ctrl.TxBuffer.Put=0;
  Uart0Ctrl.RcBuffer.Get=0;
  Uart0Ctrl.RcBuffer.Put=0;
  Uart0Ctrl.UartTxTransmit=0;  
}

uint8 Uart0TxBufferCheck(void){
  if(Uart0Ctrl.TxBuffer.Put!=Uart0Ctrl.TxBuffer.Get) {
    if(Uart0Ctrl.TxBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
      if(Uart0Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart0Ctrl.TxBuffer.Put+1)==Uart0Ctrl.TxBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

uint8 Uart0TxBufferCheckIsr(void){
  if(Uart0Ctrl.TxBuffer.Put!=Uart0Ctrl.TxBuffer.Get) {
    if(Uart0Ctrl.TxBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
      if(Uart0Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart0Ctrl.TxBuffer.Put+1)==Uart0Ctrl.TxBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

void Uart0TxBufferPut(uint8 ucData){
  if(Uart0TxBufferCheck()==BUFFER_FULL) return;
  if(Uart0Ctrl.TxBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
    Uart0Ctrl.TxBuffer.Data[UART0_MAX_BUFFER_SIZE-1]=ucData;
    Uart0Ctrl.TxBuffer.Put=0;
  }
  else {
    Uart0Ctrl.TxBuffer.Data[Uart0Ctrl.TxBuffer.Put]=ucData;
    Uart0Ctrl.TxBuffer.Put++;
  }
}

uint8 Uart0TxBufferGet(void) {
  uint8 Data;

  if(Uart0TxBufferCheck()==BUFFER_EMPTY) return 0;
  if(Uart0Ctrl.TxBuffer.Get==(UART0_MAX_BUFFER_SIZE-1)) {
    Data=Uart0Ctrl.TxBuffer.Data[UART0_MAX_BUFFER_SIZE-1];
    Uart0Ctrl.TxBuffer.Get=0;
  }
  else {
    Data=Uart0Ctrl.TxBuffer.Data[Uart0Ctrl.TxBuffer.Get];
    Uart0Ctrl.TxBuffer.Get++;
  }
  return Data;
}

uint8 Uart0RxBufferCheck(void) {
  if(Uart0Ctrl.RcBuffer.Put!=Uart0Ctrl.RcBuffer.Get) {
    if(Uart0Ctrl.RcBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
      if(Uart0Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart0Ctrl.RcBuffer.Put+1)==Uart0Ctrl.RcBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

uint8 Uart0RxBufferCheckIsr(void) {
  if(Uart0Ctrl.RcBuffer.Put!=Uart0Ctrl.RcBuffer.Get) {
    if(Uart0Ctrl.RcBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
      if(Uart0Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart0Ctrl.RcBuffer.Put+1)==Uart0Ctrl.RcBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

//Uart0RxBufferPut is called in isr only
void Uart0RxBufferPut(uint8 Data) {
  if(Uart0RxBufferCheck()==BUFFER_FULL) return;
  if(Uart0Ctrl.RcBuffer.Put==(UART0_MAX_BUFFER_SIZE-1)) {
    Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Put]=Data;
    Uart0Ctrl.RcBuffer.Put=0;
  }
  else {
    Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Put]=Data;
    Uart0Ctrl.RcBuffer.Put++;
  }
}

uint8 Uart0RxBufferGet(void) {
  uint8 Data;

  if(Uart0RxBufferCheck()==BUFFER_EMPTY) return 0;
  if(Uart0Ctrl.RcBuffer.Get==(UART0_MAX_BUFFER_SIZE-1)) {
    Data=Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Get];
    Uart0Ctrl.RcBuffer.Get=0;
  }
  else {
    Data=Uart0Ctrl.RcBuffer.Data[Uart0Ctrl.RcBuffer.Get];
    Uart0Ctrl.RcBuffer.Get++;
  }
  return Data;
}

void Uart0CharTx(char ucData){
  while(Uart0TxBufferCheck()==BUFFER_FULL) Uart0Svc(); // If buffer is full, send data right away.
  Uart0TxBufferPut(ucData);
  Uart0Svc();
}

void Uart0StringTx(char *pString) {
  while(*pString!=0) Uart0CharTx(*pString++);
}



