/****************************
*project: bluetooth low energy local network
*function: BLE peripheral using SPP profile
*uart driver for cc2541
*
*author: book chen
*file: uart1.c
*****************************
*/

#include "hal_types.h"
#include "hal_assert.h"
#include "hal_board.h"
#include "hal_defs.h"
#include "hal_mcu.h"
#include "hal_uart.h"

#include "includes.h"  // custom header files

UART1_CONTROL Uart1Ctrl;

void Uart1Init(void){
  //PERCFG &= ~0x01 //config uart 1 on P0..PERCFG (0xF1) �V Peripheral Control..in Uart1.c
  PERCFG |= 0x02;  //config uart 1 on P1..PERCFG (0xF1) �V Peripheral Control
  P1SEL  |= 0xc0;  // enable peripheral function on p1.6(uart1 tx) & p1.7(uart1 rx)
                 
  U1CSR = 0x80;    //enable uart mode,uart rx disable            
  //U0CSR = 0x84;    //enable uart mode,uart rx enable
  
  U1UCR = 0x80;    //flush unit
                   //n.8.1,low stop bit,low start bit      

  Uart1Ctrl.State=0;
  Uart1Ctrl.Timer=0;
  Uart1Ctrl.UartTxTransmit=FALSE;
  Uart1Ctrl.RcBuffer.Get=0; 
  Uart1Ctrl.RcBuffer.Put=0; 
  Uart1Ctrl.TxBuffer.Get=0; 
  Uart1Ctrl.TxBuffer.Put=0; 
}

void Uart1Open(void){
  //config baudrate
  #if (UART1_BAUDRATE==9600)
    U1BAUD=59;
    U1GCR=8;
  #elif (UART1_BAUDRATE==19200)
    U1BAUD=59;
    U1GCR=9;
  #elif (UART1_BAUDRATE==38400)
    U1BAUD=59;
    U1GCR=10;
  #elif (UART1_BAUDRATE==57600)
    U1BAUD=216;
    U1GCR=10;
  #elif (UART1_BAUDRATE==115200)
    U1BAUD=216;
    U1GCR=11;
  #endif
    
  U1UCR=0x02; //n.8.1,high stop bit,low start bit..default
  URX1IE=1; //enable UART 0 recevie interrupt
  UTX1IF=1; //Prime the ISR pump..need?
  U1CSR=0x80+0x40; //uart mode + receive enable   
  
}

void Uart1Svc(void){
    if(Uart1Ctrl.UartTxTransmit==1) return;
    if(Uart1TxBufferCheck()==BUFFER_EMPTY) return;
    Uart1Ctrl.UartTxTransmit=1;
    IEN2 |= 0x08; // Enable Tx Empty Interrupt. (Trigger first one) 
}

void Uart1Write(uint8 *pData,uint8 Length){
  if(Length==0) return;
  while(Length){
    while(Uart1TxBufferCheck()==BUFFER_FULL) Uart1Svc();
    Uart1TxBufferPut(*pData);
    Length--;
    pData++;
  }
  Uart1Svc();
}

/*************
* interrupt service routine for Uart1
**************/

HAL_ISR_FUNCTION( halUart1RxIsr, URX1_VECTOR )
{
  HAL_ENTER_ISR();
  Uart1RxBufferPut(U1DBUF);
  HAL_EXIT_ISR();
}

HAL_ISR_FUNCTION( halUart1TxIsr, UTX1_VECTOR )
{  
  HAL_ENTER_ISR();
  if(Uart1TxBufferCheckIsr()!=BUFFER_EMPTY){
    UTX1IF=0; //clear interrupt flag
    U1DBUF=Uart1TxBufferGet(); 
  }
  else {
    Uart1Ctrl.UartTxTransmit=FALSE;
    IEN2 &= ~0x08; //UTX1IE; disable Uart1 tx interrupt	
  }
  HAL_EXIT_ISR(); 
}


/*************
* buffer control library for Uart1
**************/
void Uart1BufferReset(void){
  Uart1Ctrl.TxBuffer.Get=0;
  Uart1Ctrl.TxBuffer.Put=0;
  Uart1Ctrl.RcBuffer.Get=0;
  Uart1Ctrl.RcBuffer.Put=0;
  Uart1Ctrl.UartTxTransmit=0;  
}

uint8 Uart1TxBufferCheck(void){
  if(Uart1Ctrl.TxBuffer.Put!=Uart1Ctrl.TxBuffer.Get) {
    if(Uart1Ctrl.TxBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
      if(Uart1Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart1Ctrl.TxBuffer.Put+1)==Uart1Ctrl.TxBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

uint8 Uart1TxBufferCheckIsr(void){
  if(Uart1Ctrl.TxBuffer.Put!=Uart1Ctrl.TxBuffer.Get) {
    if(Uart1Ctrl.TxBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
      if(Uart1Ctrl.TxBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart1Ctrl.TxBuffer.Put+1)==Uart1Ctrl.TxBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

void Uart1TxBufferPut(uint8 ucData){
  if(Uart1TxBufferCheck()==BUFFER_FULL) return;
  if(Uart1Ctrl.TxBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
    Uart1Ctrl.TxBuffer.Data[UART1_MAX_BUFFER_SIZE-1]=ucData;
    Uart1Ctrl.TxBuffer.Put=0;
  }
  else {
    Uart1Ctrl.TxBuffer.Data[Uart1Ctrl.TxBuffer.Put]=ucData;
    Uart1Ctrl.TxBuffer.Put++;
  }
}

uint8 Uart1TxBufferGet(void) {
  uint8 Data;

  if(Uart1TxBufferCheck()==BUFFER_EMPTY) return 0;
  if(Uart1Ctrl.TxBuffer.Get==(UART1_MAX_BUFFER_SIZE-1)) {
    Data=Uart1Ctrl.TxBuffer.Data[UART1_MAX_BUFFER_SIZE-1];
    Uart1Ctrl.TxBuffer.Get=0;
  }
  else {
    Data=Uart1Ctrl.TxBuffer.Data[Uart1Ctrl.TxBuffer.Get];
    Uart1Ctrl.TxBuffer.Get++;
  }
  return Data;
}

uint8 Uart1RxBufferCheck(void) {
  if(Uart1Ctrl.RcBuffer.Put!=Uart1Ctrl.RcBuffer.Get) {
    if(Uart1Ctrl.RcBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
      if(Uart1Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart1Ctrl.RcBuffer.Put+1)==Uart1Ctrl.RcBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

uint8 Uart1RxBufferCheckIsr(void) {
  if(Uart1Ctrl.RcBuffer.Put!=Uart1Ctrl.RcBuffer.Get) {
    if(Uart1Ctrl.RcBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
      if(Uart1Ctrl.RcBuffer.Get==0) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
    else {
      if((Uart1Ctrl.RcBuffer.Put+1)==Uart1Ctrl.RcBuffer.Get) return BUFFER_FULL;
      else return BUFFER_NOT_EMPTY;
    }
  }
  else return BUFFER_EMPTY;
}

void Uart1RxBufferPut(uint8 Data) {
  if(Uart1RxBufferCheck()==BUFFER_FULL) return;
  if(Uart1Ctrl.RcBuffer.Put==(UART1_MAX_BUFFER_SIZE-1)) {
    Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Put]=Data;
    Uart1Ctrl.RcBuffer.Put=0;
  }
  else {
    Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Put]=Data;
    Uart1Ctrl.RcBuffer.Put++;
  }
}

uint8 Uart1RxBufferGet(void) {
  uint8 Data;

  if(Uart1RxBufferCheck()==BUFFER_EMPTY) return 0;
  if(Uart1Ctrl.RcBuffer.Get==(UART1_MAX_BUFFER_SIZE-1)) {
    Data=Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Get];
    Uart1Ctrl.RcBuffer.Get=0;
  }
  else {
    Data=Uart1Ctrl.RcBuffer.Data[Uart1Ctrl.RcBuffer.Get];
    Uart1Ctrl.RcBuffer.Get++;
  }
  return Data;
}

void Uart1CharTx(char ucData){
  while(Uart1TxBufferCheck()==BUFFER_FULL) Uart1Svc(); // If buffer is full, send data right away.
  Uart1TxBufferPut(ucData);
  Uart1Svc();
}

void Uart1StringTx(char *pString) {
  while(*pString!=0) Uart1CharTx(*pString++);
}

