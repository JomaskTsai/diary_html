/*******************************************************************************
 * sdp-search.c
 * 
 * Example 3.7 sdp-search.c
 *  - Bluetooth Essentials for Programmers
 * 
 * Compile: sudo gcc sdp-search.c -lbluetooth -o sdp-search
 * 
 * Description:
 *  取得 rfcomm channel number
 * 
 * How to test: 
 *  1.) 開啟 BTSCmode 手機程式，並開啟藍牙
 *  2.) 輸入 sudo ./rfcomm-port-search { bluetooth device address }
 *      成功後會回傳 RFCOMM 的 Port number
 *      > found service running on RFCOMM port 19
 * 
 * Result: Work !!!
 * 
 * ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>

int main(int argc, char **argv)
{
    int status;
    bdaddr_t target;
    uuid_t svc_uuid;
    sdp_list_t *response_list, *search_list, *attrid_list;
    sdp_session_t *session = 0;
    uint32_t range = 0x0000ffff;
    uint8_t port = 0;

    if(argc < 2)
    {
        fprintf(stderr, "usage: %s <bt_addr>\n", argv[0]);
        exit(2);
    }
    str2ba( argv[1], &target );

    // connect to the SDP server running on the remote machine
    session = sdp_connect( BDADDR_ANY, &target, 0 );
    
    // When searching for a standard reserved UUID, the usual case,
    //  use the function sdp_uuid16_create() or sdp_uuin32_create().
    sdp_uuid16_create( &svc_uuid, RFCOMM_UUID );
    search_list = sdp_list_append( 0, &svc_uuid );
    attrid_list = sdp_list_append( 0, &range );

    // get a list of service records that have UUID 0xabcd
    response_list = NULL;
    status = sdp_service_search_attr_req( session, search_list,
            SDP_ATTR_REQ_RANGE, attrid_list, &response_list);

    if( status == 0 ) {
        sdp_list_t *proto_list = NULL;
        sdp_list_t *r = response_list;
        
        // go through each of the service records
        for (; r; r = r->next ) {
            sdp_record_t *rec = (sdp_record_t*) r->data;
            
            // get a list of the protocol sequences
            if( sdp_get_access_protos( rec, &proto_list ) == 0 ) {

                // get the RFCOMM port number
                port = sdp_get_proto_port( proto_list, RFCOMM_UUID );

                sdp_list_free( proto_list, 0 );
            }
            sdp_record_free( rec );
        }
    }
    sdp_list_free( response_list, 0 );
    sdp_list_free( search_list, 0 );
    sdp_list_free( attrid_list, 0 );
    sdp_close( session );

    if( port != 0 ) {
        printf("found service running on RFCOMM port %d\n", port);
    }
    
    return 0;
}