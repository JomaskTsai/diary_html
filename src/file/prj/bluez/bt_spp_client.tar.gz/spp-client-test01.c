/*******************************************************************************
* spp-client-test01.c
*  SPP client test 01
* 
* Compile: sudo gcc spp-client-test01.c -lbluetooth -o spp-client-test01
* 
* Description:
*   手機作為藍牙 SPP Server，讓 藍牙 SPP Client 可以連接並互傳訊息。
*   01: 連接成功之後，回傳 10 次 hello! 字串做為測試
*  
* How to test: 
*   Raspberry Pi + USB Bluetooth Dongle <--> Android phone
*  1.) 開啟手機 BTSCmode，並開啟藍牙
*  2.) 在樹莓派命令提示視窗下輸入 sudo ./spp-client
*      一開始會輸出所連結的 RFCOMM channel number。
*      停頓 5 秒之後，每隔一秒輸出 hello! 一次，共 10 次。
*  
* Result: OK !!!
*  連接上 BTSCmode SPP Server 後，會先輸出所連結的 RFCOMM channel number，
*  等待 5 秒鐘之後，每隔一秒輸出 hello! 一次，共 10 次。
*  若再一次輸入 sudo ./spp-client，手機視窗上並不會繼續輸出任何字串；要返回
*  前一個畫面再次按下 AS Server 按鈕，才會再次成功連接並輸出 hello!
* 
* ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>
#include <sys/socket.h>
#include <bluetooth/rfcomm.h>

//-- 搜尋遠端 SPP Server 所使用的 RFCOMM Port Number
// 回傳 RFCOMM Port Number
uint8_t get_rfcomm_port_number( const char bta[] )
{
    int status;
    bdaddr_t target;
    uuid_t svc_uuid;
    sdp_list_t *response_list, *search_list, *attrid_list;
    sdp_session_t *session = 0;
    uint32_t range = 0x0000ffff;
    uint8_t port = 0;

    str2ba( bta, &target );

    // connect to the SDP server running on the remote machine
    session = sdp_connect( BDADDR_ANY, &target, 0 );

    sdp_uuid16_create( &svc_uuid, RFCOMM_UUID );
    search_list = sdp_list_append( 0, &svc_uuid );
    attrid_list = sdp_list_append( 0, &range );

    // get a list of service records that have UUID 0xabcd
    response_list = NULL;
    status = sdp_service_search_attr_req( session, search_list,
            SDP_ATTR_REQ_RANGE, attrid_list, &response_list);

    if( status == 0 ) {
        sdp_list_t *proto_list = NULL;
        sdp_list_t *r = response_list;
        
        // go through each of the service records
        for (; r; r = r->next ) {
            sdp_record_t *rec = (sdp_record_t*) r->data;
            
            // get a list of the protocol sequences
            if( sdp_get_access_protos( rec, &proto_list ) == 0 ) {

                // get the RFCOMM port number
                port = sdp_get_proto_port( proto_list, RFCOMM_UUID );

                sdp_list_free( proto_list, 0 );
            }
            sdp_record_free( rec );
        }
    }
    sdp_list_free( response_list, 0 );
    sdp_list_free( search_list, 0 );
    sdp_list_free( attrid_list, 0 );
    sdp_close( session );

    if( port != 0 ) {
        printf("found service running on RFCOMM port %d\n", port);
    }
    
    return port;
}

int main(int argc, char **argv)
{
    struct sockaddr_rc addr = { 0 };
    int s, status, i;
    //char dest[18] = "00:14:03:07:04:20"; // connect to win 8, HC-06, slave, WORK!!
    //char dest[18] = "00:14:02:12:07:69"; // connect to win 8, HC-05, slave, WORK!!
    char dest[18] = "D0:51:62:9C:A8:2B"; // connect to android phone, usb bt dongle slave, WORK!!

    // allocate a socket
    s = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

    // set the connection parameters (who to connect to)
    addr.rc_family = AF_BLUETOOTH;
    /*
        對於藍牙串口助手，程式不需要特別去找 Channel number
        ，但是 BTSCmode 是使用固定 Channel number
        所以需要被搜尋：
        1.) 打開手機藍牙並設為可搜尋
        2.) 在樹莓派命令提示視窗下 sdptool browse 11:22:33:44:55:66 <-- 手機藍牙位址
            Service Name: btspp
            Service RecHandle: 0x10009
            Service Class ID List:
              UUID 128: 00001101-0000-1000-8000-00805f9b34fb
            Protocol Descriptor List:
              "L2CAP" (0x0100)
              "RFCOMM" (0x0003)
                Channel: 5
    */
    addr.rc_channel = get_rfcomm_port_number(dest);
    str2ba( dest, &addr.rc_bdaddr );

    //  等幾秒鐘之後再連接到 SPP Server
    sleep(5);
    // connect to server
    status = connect(s, (struct sockaddr *)&addr, sizeof(addr));

    // send a message
    if( status == 0 ) {
        for(i = 0; i < 10; i++)
        {
            status = send(s, "hello!", 6, 0);
            sleep(1);
            if( status < 0 ) perror( "rfcomm send " );
        }
    }
    else if( status < 0 )
    {
        perror("uh oh");
    }

    close(s);
    return 0;
}